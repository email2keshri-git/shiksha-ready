# Shiksha Sudhar

A school-fundraising platform: React frontend + Node/Express API + Prisma/MySQL database.

## Structure

```
shiksha-sudhar/
  frontend/   React + TypeScript + Tailwind CSS (Vite)
  backend/    Node.js + Express + Prisma (MySQL)
```

## Quick start — stub mode (no database needed)

By default the backend serves in-memory mock data, so you can build/review the
whole UI before MySQL is set up at all.

```bash
cd backend
cp .env.example .env      # USE_MOCK_DATA=true is the default — leave it as-is
npm install
npm run dev                # http://localhost:4000
```

```bash
# new terminal
cd frontend
npm install
npm run dev                 # http://localhost:5173
```

Open http://localhost:5173 — the homepage renders real data served by the API
(check the backend terminal for `GET /api/projects 200` logs), just backed by an
in-memory array instead of MySQL. Donations also work end-to-end in "demo mode":
`/api/donations/order` returns a fake order id and `/verify` skips signature
checking, so you can test the full donate flow without a Razorpay account.

The frontend calls `/api/*`, which Vite proxies to `http://localhost:4000` in dev
(see `vite.config.ts`). If the backend isn't running at all, the homepage falls
back further, to hardcoded data baked into the frontend (`src/lib/mockData.ts`) —
so the UI still renders even with zero backend running.

## Switching on MySQL

Once you're ready to persist real data:

### 1. Start MySQL

```sql
CREATE DATABASE shiksha_sudhar;
```

Or with Docker, if you don't want to install MySQL directly:

```bash
docker run --name shiksha-mysql -e MYSQL_ROOT_PASSWORD=yourpassword \
  -e MYSQL_DATABASE=shiksha_sudhar -p 3306:3306 -d mysql:8
```

### 2. Update backend/.env

```bash
USE_MOCK_DATA=false
DATABASE_URL="mysql://root:yourpassword@localhost:3306/shiksha_sudhar"
```

### 3. Migrate and seed

```bash
cd backend
npx prisma migrate dev --name init
npm run prisma:seed
npm run dev
```

No frontend or route code needs to change — `USE_MOCK_DATA` is the only switch
(see `backend/src/repositories/index.js`). Routes call a repository interface
that's implemented once against the in-memory stub and once against Prisma.

## What's included

**Backend**
- `GET /api/projects` — featured/active projects, with computed funding progress
- `GET /api/projects/:id` — single project
- `GET /api/stats`, `/api/stories`, `/api/partners` — homepage content
- `POST /api/donations/order` — creates a Razorpay order + pending donation record
- `POST /api/donations/verify` — verifies the Razorpay signature server-side, marks
  the donation successful, and increments the project's raised amount
- Prisma schema modeling School, Project, Donation, Story, Partner, ImpactStat
- Rate limiting on donation endpoints, helmet, CORS, centralized error handling

**Frontend**
- Componentized homepage matching the design: Navbar, Hero, stats bar, featured
  projects grid with progress bars, "where your donation goes", impact section,
  stories, partners, closing CTA, footer
- Typed API client with graceful fallback to mock data
- Tailwind theme tuned to the brand palette (orange `#E1621B`, deep green `#1F4D3D`)

## Next steps to make this production-ready

1. **Payments**: sign up for a Razorpay account, drop real keys into `backend/.env`,
   and wire up `razorpay-checkout` (or their hosted checkout script) on the frontend
   donate button to call `/api/donations/order` then `/api/donations/verify`.
2. **Auth**: add a real auth flow (e.g. JWT + bcrypt, or a provider like Clerk/Auth0)
   for the "Login" button — currently a placeholder.
3. **Images**: replace the Unsplash placeholder photos with real school photos, and
   set up file uploads (e.g. S3 or Cloudinary) for admin-added projects.
4. **Admin panel**: a simple internal dashboard to add/edit projects, mark donations,
   and generate 80G tax receipts (the schema already tracks `panNumber` and
   `receiptUrl` for this).
5. **Database**: for production, point `DATABASE_URL` at a managed MySQL instance
   (PlanetScale, AWS RDS, Railway MySQL, etc.) instead of a local server.
6. **Deployment**: frontend to Vercel/Netlify; backend to Render/Railway/Fly.io with
   a managed MySQL add-on.
