import { Link } from 'react-router-dom';
import type { Story } from '../types';

const avatarColors = ['#2E8BE0', '#2E9E5B', '#7C4DDB', '#E1621B', '#1B8A8A', '#F3A93B'];

function colorFor(id: string) {
  let hash = 0;
  for (const ch of id) hash += ch.charCodeAt(0);
  return avatarColors[hash % avatarColors.length];
}

export function StoryCard({ story }: { story: Story }) {
  return (
    <div className="flex gap-3 rounded-xl border border-gray-100 bg-white p-4 shadow-sm">
      {story.imageUrl ? (
        <img
          src={story.imageUrl}
          alt={story.authorName}
          className="h-14 w-14 flex-shrink-0 rounded-lg object-cover"
        />
      ) : (
        <div
          className="flex h-14 w-14 flex-shrink-0 items-center justify-center rounded-lg text-lg font-bold text-white"
          style={{ backgroundColor: colorFor(story.id) }}
        >
          {story.authorName.trim().charAt(0).toUpperCase()}
        </div>
      )}
      <div>
        <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" className="text-brand-orange">
          <path d="M7 7h4v6c0 2.2-1.8 4-4 4v-2c1.1 0 2-.9 2-2H7zM15 7h4v6c0 2.2-1.8 4-4 4v-2c1.1 0 2-.9 2-2h-2z" />
        </svg>
        <p className="mt-1 text-sm leading-relaxed text-gray-700">{story.quote}</p>
        <p className="mt-2 text-xs font-semibold text-brand-green">{story.authorName}</p>
        <p className="text-xs text-gray-500">{story.authorRole}</p>
      </div>
    </div>
  );
}

export default function Stories({ stories }: { stories: Story[] }) {
  return (
    <section id="stories" className="mx-auto max-w-7xl px-6 py-9">
      <div className="mb-8 flex items-end justify-between">
        <div>
          <h2 className="text-2xl font-bold text-brand-green sm:text-3xl">Stories of Change</h2>
          <p className="mt-1 text-sm text-gray-600">
            Real stories from schools, students and communities.
          </p>
        </div>
        <Link to="/stories" className="hidden text-sm font-medium text-brand-green hover:text-brand-orange sm:block">
          View all stories →
        </Link>
      </div>

      <div className="grid gap-4 sm:grid-cols-3">
        {stories.map((story) => (
          <StoryCard key={story.id} story={story} />
        ))}
      </div>

      <Link
        to="/stories"
        className="mt-8 block w-full rounded-md border border-gray-300 py-2.5 text-center text-sm font-semibold text-brand-green hover:border-brand-green hover:bg-brand-cream sm:hidden"
      >
        View all stories →
      </Link>
    </section>
  );
}
