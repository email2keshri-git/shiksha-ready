import { useEffect, useRef, useState } from 'react';
import { useAuth } from '../lib/auth';

const CLIENT_ID = import.meta.env.VITE_GOOGLE_CLIENT_ID as string | undefined;
const GIS_SRC = 'https://accounts.google.com/gsi/client';

declare global {
  interface Window {
    google?: {
      accounts: {
        id: {
          initialize: (config: {
            client_id: string;
            callback: (res: { credential: string }) => void;
          }) => void;
          renderButton: (parent: HTMLElement, options: Record<string, unknown>) => void;
        };
      };
    };
  }
}

function loadGis(): Promise<boolean> {
  return new Promise((resolve) => {
    if (window.google?.accounts?.id) return resolve(true);
    const existing = document.querySelector(`script[src="${GIS_SRC}"]`);
    if (existing) {
      existing.addEventListener('load', () => resolve(true));
      existing.addEventListener('error', () => resolve(false));
      return;
    }
    const script = document.createElement('script');
    script.src = GIS_SRC;
    script.async = true;
    script.onload = () => resolve(true);
    script.onerror = () => resolve(false);
    document.head.appendChild(script);
  });
}

// Renders Google's official Sign-In button when a client id is configured,
// verifies the returned credential with our backend, then calls onSuccess.
// Falls back to a disabled-looking button with a note when not configured.
export default function GoogleSignInButton({ onSuccess }: { onSuccess: () => void }) {
  const { loginWithGoogle } = useAuth();
  const containerRef = useRef<HTMLDivElement>(null);
  const [error, setError] = useState('');
  const [notConfigured, setNotConfigured] = useState(!CLIENT_ID);

  useEffect(() => {
    if (!CLIENT_ID) return;
    let cancelled = false;

    loadGis().then((ok) => {
      if (cancelled || !ok || !window.google || !containerRef.current) {
        setNotConfigured(true);
        return;
      }
      window.google.accounts.id.initialize({
        client_id: CLIENT_ID,
        callback: async (res) => {
          try {
            await loginWithGoogle(res.credential);
            onSuccess();
          } catch (err) {
            setError(err instanceof Error ? err.message : 'Google sign-in failed');
          }
        },
      });
      window.google.accounts.id.renderButton(containerRef.current, {
        theme: 'outline',
        size: 'large',
        width: 360,
        text: 'continue_with',
        logo_alignment: 'center',
      });
    });

    return () => {
      cancelled = true;
    };
  }, [loginWithGoogle, onSuccess]);

  if (notConfigured) {
    return (
      <div>
        <button
          type="button"
          onClick={() => setError('Google sign-in is not configured yet.')}
          className="flex w-full items-center justify-center gap-2 rounded-md border border-gray-300 px-4 py-2.5 text-sm font-semibold text-gray-700 hover:bg-gray-50"
        >
          <svg width="18" height="18" viewBox="0 0 24 24" aria-hidden>
            <path fill="#4285F4" d="M23 12.3c0-.8-.1-1.6-.2-2.3H12v4.5h6.2a5.3 5.3 0 0 1-2.3 3.5v2.9h3.7C21.8 19 23 15.9 23 12.3z" />
            <path fill="#34A853" d="M12 24c3.2 0 5.9-1.1 7.8-2.9l-3.7-2.9c-1 .7-2.4 1.1-4.1 1.1-3.1 0-5.8-2.1-6.8-5H1.3v3C3.2 21.3 7.3 24 12 24z" />
            <path fill="#FBBC05" d="M5.2 14.3a7.2 7.2 0 0 1 0-4.6v-3H1.3a12 12 0 0 0 0 10.6z" />
            <path fill="#EA4335" d="M12 4.8c1.8 0 3.3.6 4.6 1.8l3.4-3.4C17.9 1.2 15.2 0 12 0 7.3 0 3.2 2.7 1.3 6.7l3.9 3a7.2 7.2 0 0 1 6.8-4.9z" />
          </svg>
          Continue with Google
        </button>
        {error && <p className="mt-2 text-center text-sm text-gray-500">{error}</p>}
      </div>
    );
  }

  return (
    <div>
      <div ref={containerRef} className="flex justify-center" />
      {error && <p className="mt-2 text-center text-sm text-red-600">{error}</p>}
    </div>
  );
}
