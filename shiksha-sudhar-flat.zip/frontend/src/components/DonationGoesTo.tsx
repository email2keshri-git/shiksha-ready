const items = [
  {
    label: 'Classrooms & Buildings',
    bg: '#F3A93B',
    icon: <path d="M3 21h18M5 21V7l7-4 7 4v14M10 21v-5h4v5" />,
  },
  {
    label: 'Clean Water & Sanitation',
    bg: '#2E8BE0',
    icon: <path d="M12 2.5S5 10 5 14a7 7 0 0 0 14 0c0-4-7-11.5-7-11.5z" />,
  },
  {
    label: 'Learning Materials & Libraries',
    bg: '#2E9E5B',
    icon: <path d="M12 6.5C10.5 5 8 4.5 4 4.5v14c4 0 6.5.5 8 2 1.5-1.5 4-2 8-2v-14c-4 0-6.5.5-8 2zM12 6.5v13" />,
  },
  {
    label: 'Digital Education',
    bg: '#7C4DDB',
    icon: <path d="M4 5h16v11H4zM2 20h20M9 20l.5-4M15 20l-.5-4" />,
  },
  {
    label: 'Sports & Playgrounds',
    bg: '#E1621B',
    icon: <path d="M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM12 3l3 4-3 3-3-3zM4 9l4 1 1 4-3 2M20 9l-4 1-1 4 3 2" />,
  },
  {
    label: 'Teacher Training & Support',
    bg: '#1B8A8A',
    icon: <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75" />,
  },
];

export default function DonationGoesTo() {
  return (
    <section className="bg-brand-cream">
      <div className="mx-auto max-w-7xl px-6 py-6">
        <h2 className="text-2xl font-bold text-gray-900 sm:text-3xl">Where Your Donation Goes</h2>
        <p className="mt-1 max-w-2xl text-sm text-gray-600">
          Your support directly funds school infrastructure, learning resources and essential
          facilities.
        </p>

        <div className="mt-8 grid grid-cols-2 gap-y-8 sm:grid-cols-3 lg:grid-cols-6">
          {items.map((item, i) => (
            <div
              key={item.label}
              className={`flex flex-col items-center px-3 text-center ${
                i !== 0 ? 'lg:border-l lg:border-black/10' : ''
              }`}
            >
              <div
                className="mb-3 flex h-11 w-11 items-center justify-center rounded-[10px] text-white"
                style={{ backgroundColor: item.bg }}
              >
                <svg
                  width="22"
                  height="22"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="1.8"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  {item.icon}
                </svg>
              </div>
              <p className="text-[13px] font-semibold leading-snug text-gray-900">{item.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
