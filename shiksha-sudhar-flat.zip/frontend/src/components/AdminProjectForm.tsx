import { useState } from 'react';
import { createProject } from '../lib/api';
import type { Project, ProjectCategory } from '../types';

const categories: { value: ProjectCategory; label: string }[] = [
  { value: 'INFRASTRUCTURE', label: 'Infrastructure' },
  { value: 'SANITATION', label: 'Sanitation' },
  { value: 'DIGITAL_LEARNING', label: 'Digital learning' },
  { value: 'LIBRARY', label: 'Library' },
  { value: 'SPORTS', label: 'Sports' },
  { value: 'TEACHER_TRAINING', label: 'Teacher training' },
];

const empty = {
  title: '',
  description: '',
  category: 'INFRASTRUCTURE' as ProjectCategory,
  imageUrl: '',
  goalAmount: '',
  school: '',
};

export default function AdminProjectForm({ onCreated }: { onCreated: (p: Project) => void }) {
  const [form, setForm] = useState(empty);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [saving, setSaving] = useState(false);

  function update<K extends keyof typeof form>(key: K, value: (typeof form)[K]) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setSuccess('');
    const goal = Number(form.goalAmount);
    if (!form.title.trim() || !form.description.trim() || !form.school.trim() || !form.imageUrl.trim()) {
      setError('Please fill in all fields.');
      return;
    }
    if (!goal || goal <= 0) {
      setError('Goal amount must be a positive number (in rupees).');
      return;
    }
    setSaving(true);
    try {
      const project = await createProject({
        title: form.title.trim(),
        description: form.description.trim(),
        category: form.category,
        imageUrl: form.imageUrl.trim(),
        goalAmount: Math.floor(goal),
        school: form.school.trim(),
      });
      setSuccess(`“${project.title}” was created.`);
      setForm(empty);
      onCreated(project);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not create project.');
    } finally {
      setSaving(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="rounded-xl border border-gray-100 bg-white p-6 shadow-sm">
      <h2 className="text-lg font-bold text-brand-green">Create a new project</h2>
      <p className="mt-0.5 text-sm text-gray-600">Saved to the database and shown on the Projects page.</p>

      <div className="mt-5 grid gap-4 sm:grid-cols-2">
        <Field label="Title" value={form.title} onChange={(v) => update('title', v)} placeholder="Build 3 new classrooms" />
        <Field label="School" value={form.school} onChange={(v) => update('school', v)} placeholder="Zila Parishad School, Karnataka" />

        <div className="sm:col-span-2">
          <label className="block text-sm font-medium text-gray-700" htmlFor="p-desc">Description</label>
          <textarea
            id="p-desc"
            value={form.description}
            onChange={(e) => update('description', e.target.value)}
            rows={2}
            placeholder="Help us build additional classrooms to accommodate more students."
            className="mt-1 w-full rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-brand-green focus:outline-none focus:ring-1 focus:ring-brand-green"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700" htmlFor="p-cat">Category</label>
          <select
            id="p-cat"
            value={form.category}
            onChange={(e) => update('category', e.target.value as ProjectCategory)}
            className="mt-1 w-full rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-brand-green focus:outline-none focus:ring-1 focus:ring-brand-green"
          >
            {categories.map((c) => (
              <option key={c.value} value={c.value}>{c.label}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700" htmlFor="p-goal">Goal amount (₹)</label>
          <input
            id="p-goal"
            type="number"
            min={1}
            value={form.goalAmount}
            onChange={(e) => update('goalAmount', e.target.value)}
            placeholder="1500000"
            className="mt-1 w-full rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-brand-green focus:outline-none focus:ring-1 focus:ring-brand-green"
          />
        </div>

        <Field
          label="Image URL"
          value={form.imageUrl}
          onChange={(v) => update('imageUrl', v)}
          placeholder="/images/Infrastructure.png"
          className="sm:col-span-2"
        />
      </div>

      {error && <p className="mt-4 rounded-md bg-red-50 px-3 py-2 text-sm text-red-700">{error}</p>}
      {success && <p className="mt-4 rounded-md bg-green-50 px-3 py-2 text-sm text-brand-green">{success}</p>}

      <button
        type="submit"
        disabled={saving}
        className="mt-5 rounded-md bg-brand-orange px-6 py-2.5 text-sm font-semibold text-white hover:bg-brand-orange-dark disabled:opacity-60"
      >
        {saving ? 'Saving…' : 'Create project'}
      </button>
    </form>
  );
}

function Field({
  label,
  value,
  onChange,
  placeholder,
  className = '',
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  className?: string;
}) {
  return (
    <div className={className}>
      <label className="block text-sm font-medium text-gray-700">{label}</label>
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="mt-1 w-full rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-brand-green focus:outline-none focus:ring-1 focus:ring-brand-green"
      />
    </div>
  );
}
