import { Link } from 'react-router-dom';
import type { Project } from '../types';

const categoryLabel: Record<Project['category'], string> = {
  INFRASTRUCTURE: 'Infrastructure',
  SANITATION: 'Sanitation',
  DIGITAL_LEARNING: 'Digital learning',
  LIBRARY: 'Library',
  SPORTS: 'Sports',
  TEACHER_TRAINING: 'Teacher training',
};

const categoryColor: Record<Project['category'], string> = {
  INFRASTRUCTURE: 'bg-brand-orange',
  SANITATION: 'bg-brand-green',
  DIGITAL_LEARNING: 'bg-sky-600',
  LIBRARY: 'bg-purple-600',
  SPORTS: 'bg-rose-500',
  TEACHER_TRAINING: 'bg-teal-600',
};

// Soft tints used as a fallback background when a project has no image.
const categoryTint: Record<Project['category'], string> = {
  INFRASTRUCTURE: '#cfd9d0',
  SANITATION: '#d7ccc0',
  DIGITAL_LEARNING: '#c3d3e0',
  LIBRARY: '#e0d3c3',
  SPORTS: '#d0d8c3',
  TEACHER_TRAINING: '#cbd0e0',
};

function formatRupees(amount: number) {
  return `₹${amount.toLocaleString('en-IN')}`;
}

export function ProjectCard({ project }: { project: Project }) {
  return (
    <div className="overflow-hidden rounded-xl border border-gray-100 bg-white shadow-sm transition hover:shadow-md">
      <div className="relative">
        {project.imageUrl ? (
          <img src={project.imageUrl} alt={project.title} className="h-44 w-full object-cover" />
        ) : (
          <div className="h-44 w-full" style={{ backgroundColor: categoryTint[project.category] }} />
        )}
        <span
          className={`absolute left-3 top-3 rounded px-2.5 py-1 text-xs font-semibold text-white ${categoryColor[project.category]}`}
        >
          {categoryLabel[project.category]}
        </span>
      </div>
      <div className="p-5">
        <h3 className="text-lg font-bold text-brand-green">{project.title}</h3>
        <p className="mt-1 text-sm font-medium text-brand-orange">{project.school}</p>
        <p className="mt-2 text-sm text-gray-600">{project.description}</p>

        <div className="mt-4">
          <div className="h-2 w-full overflow-hidden rounded-full bg-gray-100">
            <div
              className="h-full rounded-full bg-brand-green"
              style={{ width: `${project.progress}%` }}
            />
          </div>
          <div className="mt-2 flex items-center justify-between text-xs text-gray-600">
            <span>
              {formatRupees(project.raisedAmount)} raised of {formatRupees(project.goalAmount)}
            </span>
            <span className="font-medium text-brand-green">{project.progress}%</span>
          </div>
          {project.donorCount ? (
            <p className="mt-1 text-xs text-gray-400">
              {project.donorCount.toLocaleString('en-IN')} donors
            </p>
          ) : null}
        </div>

        <Link
          to={`/donate?project=${project.id}`}
          className="mt-4 block w-full rounded-md bg-brand-orange py-2.5 text-center text-sm font-medium text-white hover:bg-brand-orange-dark"
        >
          Donate now
        </Link>
      </div>
    </div>
  );
}

export default function FeaturedProjects({ projects }: { projects: Project[] }) {
  return (
    <section id="projects" className="mx-auto max-w-7xl px-6 py-9">
      <div className="mb-8 flex items-end justify-between">
        <div>
          <h2 className="text-2xl font-bold text-brand-green sm:text-3xl">
            Featured School Development Projects
          </h2>
          <p className="mt-1 text-sm text-gray-600">
            Support real projects creating real change in communities across India.
          </p>
        </div>
        <Link to="/projects" className="hidden text-sm font-medium text-brand-green hover:text-brand-orange sm:block">
          View all projects →
        </Link>
      </div>

      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {projects.map((project) => (
          <ProjectCard key={project.id} project={project} />
        ))}
      </div>

      <Link
        to="/projects"
        className="mt-8 block w-full rounded-md border border-gray-300 py-2.5 text-center text-sm font-semibold text-brand-green hover:border-brand-green hover:bg-brand-cream sm:hidden"
      >
        View all projects →
      </Link>
    </section>
  );
}
