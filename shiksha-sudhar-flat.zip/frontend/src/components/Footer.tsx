const socials = [
  {
    label: 'LinkedIn',
    icon: (
      <path d="M4.98 3.5a2.5 2.5 0 1 1 0 5 2.5 2.5 0 0 1 0-5zM3 9h4v12H3zM10 9h3.8v1.7h.05c.53-1 1.83-2.05 3.77-2.05 4.03 0 4.78 2.65 4.78 6.1V21h-4v-5.4c0-1.3 0-2.95-1.8-2.95-1.8 0-2.07 1.4-2.07 2.85V21h-4z" />
    ),
  },
  {
    label: 'Twitter',
    icon: (
      <path d="M22 5.9c-.7.32-1.5.53-2.3.63a4 4 0 0 0 1.76-2.2c-.78.46-1.64.8-2.56.98a4 4 0 0 0-6.82 3.64A11.36 11.36 0 0 1 3.9 4.8a4 4 0 0 0 1.24 5.34 4 4 0 0 1-1.8-.5v.05a4 4 0 0 0 3.2 3.92 4 4 0 0 1-1.8.07 4 4 0 0 0 3.73 2.78A8 8 0 0 1 2 18.28a11.32 11.32 0 0 0 6.12 1.8c7.34 0 11.36-6.08 11.36-11.35v-.52A8.1 8.1 0 0 0 22 5.9z" />
    ),
  },
  {
    label: 'Facebook',
    icon: (
      <path d="M14 9h3V6h-3c-2.2 0-3.5 1.3-3.5 3.6V11H8v3h2.5v7h3v-7H16l.5-3h-3V9.6c0-.4.2-.6.7-.6z" />
    ),
  },
  {
    label: 'Instagram',
    icon: (
      <path d="M7 3h10a4 4 0 0 1 4 4v10a4 4 0 0 1-4 4H7a4 4 0 0 1-4-4V7a4 4 0 0 1 4-4zm0 2a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2H7zm5 3.5a3.5 3.5 0 1 1 0 7 3.5 3.5 0 0 1 0-7zm0 2a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3zM17.5 6a1 1 0 1 1 0 2 1 1 0 0 1 0-2z" />
    ),
  },
  {
    label: 'YouTube',
    icon: (
      <path d="M22 8.2a3 3 0 0 0-2.1-2.1C18 5.5 12 5.5 12 5.5s-6 0-7.9.6A3 3 0 0 0 2 8.2 31 31 0 0 0 1.7 12 31 31 0 0 0 2 15.8a3 3 0 0 0 2.1 2.1c1.9.6 7.9.6 7.9.6s6 0 7.9-.6a3 3 0 0 0 2.1-2.1c.3-1.2.3-3.8.3-3.8s0-2.6-.3-3.8zM10 15V9l5.2 3z" />
    ),
  },
];

const navLinks = ['About', 'Schools', 'Projects', 'Impact', 'Stories', 'Contact'];
const legalLinks = ['Privacy Policy', 'Terms of Use', 'Contact'];

export default function Footer() {
  return (
    <footer className="bg-brand-green-dark text-white/70">
      <div className="mx-auto max-w-7xl px-6 py-6">
        <div className="flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between">
          <div className="max-w-xs">
            <div className="flex items-center gap-2">
              <img
                src="/images/logo/logo.jpg"
                alt="Shiksha Sudhar Foundation"
                className="h-10 w-10 rounded bg-white object-contain p-0.5"
              />
              <p className="text-lg font-bold text-white">Shiksha Sudhar</p>
            </div>
            <p className="mt-2 text-xs">Stronger Schools. Brighter Futures.</p>
          </div>

          <nav className="flex flex-wrap gap-x-6 gap-y-2 text-sm">
            {navLinks.map((l) => (
              <a key={l} href="#" className="transition hover:text-white">
                {l}
              </a>
            ))}
          </nav>

          <div className="flex gap-3">
            {socials.map((s) => (
              <a
                key={s.label}
                href="#"
                aria-label={s.label}
                className="flex h-9 w-9 items-center justify-center rounded-full bg-white/10 text-white transition hover:bg-brand-orange"
              >
                <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                  {s.icon}
                </svg>
              </a>
            ))}
          </div>
        </div>

        <div className="mt-5 flex flex-col gap-3 border-t border-white/10 pt-4 text-xs sm:flex-row sm:items-center sm:justify-between">
          <p>© {new Date().getFullYear()} Shiksha Sudhar. All rights reserved.</p>
          <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
            {legalLinks.map((l, i) => (
              <span key={l} className="flex items-center gap-x-3">
                {i > 0 && <span className="text-white/20">|</span>}
                <a href="#" className="transition hover:text-white">
                  {l}
                </a>
              </span>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}
