import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '../lib/auth';

const links: { label: string; to: string }[] = [
  { label: 'Home', to: '/' },
  { label: 'About', to: '/about' },
  { label: 'Projects', to: '/projects' },
  { label: 'Impact', to: '/impact' },
  { label: 'Stories', to: '/stories' },
  { label: 'Get Involved', to: '/get-involved' },
];

export default function Navbar() {
  const { user, logout } = useAuth();
  const { pathname } = useLocation();

  return (
    <header className="sticky top-0 z-50 border-b border-black/5 bg-white/95 backdrop-blur">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4">
        <Link to="/" className="flex items-center gap-2">
          <img
            src="/images/logo/logo.jpg"
            alt="Shiksha Sudhar Foundation"
            className="h-11 w-11 object-contain"
          />
          <div>
            <p className="text-lg font-semibold leading-tight text-brand-green">Shiksha Sudhar</p>
            <p className="text-[11px] leading-tight text-gray-500">
              Stronger Schools, Brighter Futures.
            </p>
          </div>
        </Link>

        <nav className="hidden gap-7 text-sm font-medium text-gray-700 lg:flex">
          {links.map((link) => (
            <Link
              key={link.label}
              to={link.to}
              className={pathname === link.to ? 'text-brand-orange' : 'hover:text-brand-orange'}
            >
              {link.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          <button
            aria-label="Search"
            className="hidden h-9 w-9 items-center justify-center rounded-md text-gray-600 hover:bg-gray-50 sm:flex"
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="11" cy="11" r="7" />
              <path d="M21 21l-4.3-4.3" />
            </svg>
          </button>
          {user ? (
            <>
              {user.role === 'ADMIN' && (
                <Link
                  to="/admin"
                  className="rounded-md px-3 py-2 text-sm font-semibold text-brand-green hover:text-brand-orange"
                >
                  Admin
                </Link>
              )}
              <span className="hidden text-sm font-medium text-gray-700 sm:inline">{user.name}</span>
              <button
                onClick={() => logout()}
                className="rounded-md border border-gray-300 px-4 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50"
              >
                Logout
              </button>
            </>
          ) : (
            <Link
              to="/login"
              className="rounded-md border border-gray-300 px-4 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50"
            >
              Login
            </Link>
          )}
          <Link
            to="/donate"
            className="rounded-md bg-brand-orange px-4 py-2 text-sm font-semibold text-white hover:bg-brand-orange-dark"
          >
            Donate Now
          </Link>
        </div>
      </div>
    </header>
  );
}
