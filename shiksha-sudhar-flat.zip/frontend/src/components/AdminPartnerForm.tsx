import { useState } from 'react';
import { createPartner } from '../lib/api';
import type { Partner } from '../types';

export default function AdminPartnerForm({ onCreated }: { onCreated: (p: Partner) => void }) {
  const [name, setName] = useState('');
  const [logoUrl, setLogoUrl] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [saving, setSaving] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setSuccess('');
    if (!name.trim()) {
      setError('Please enter a partner name.');
      return;
    }
    setSaving(true);
    try {
      const partner = await createPartner({ name: name.trim(), logoUrl: logoUrl.trim() || undefined });
      setSuccess(`“${partner.name}” was added.`);
      setName('');
      setLogoUrl('');
      onCreated(partner);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not add partner.');
    } finally {
      setSaving(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="rounded-xl border border-gray-100 bg-white p-6 shadow-sm">
      <h2 className="text-lg font-bold text-brand-green">Add a partner</h2>
      <p className="mt-0.5 text-sm text-gray-600">
        Saved to the database and shown in the Partners section. Leave the logo blank to show the
        name.
      </p>

      <div className="mt-5 space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700">Partner name</label>
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Reliance Foundation"
            className="mt-1 w-full rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-brand-green focus:outline-none focus:ring-1 focus:ring-brand-green"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">Logo URL (optional)</label>
          <input
            value={logoUrl}
            onChange={(e) => setLogoUrl(e.target.value)}
            placeholder="/images/partners/reliance.png"
            className="mt-1 w-full rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-brand-green focus:outline-none focus:ring-1 focus:ring-brand-green"
          />
        </div>
      </div>

      {error && <p className="mt-4 rounded-md bg-red-50 px-3 py-2 text-sm text-red-700">{error}</p>}
      {success && <p className="mt-4 rounded-md bg-green-50 px-3 py-2 text-sm text-brand-green">{success}</p>}

      <button
        type="submit"
        disabled={saving}
        className="mt-5 rounded-md bg-brand-orange px-6 py-2.5 text-sm font-semibold text-white hover:bg-brand-orange-dark disabled:opacity-60"
      >
        {saving ? 'Saving…' : 'Add partner'}
      </button>
    </form>
  );
}
