import { useState } from 'react';
import { createStory } from '../lib/api';
import type { Story } from '../types';

const empty = { quote: '', authorName: '', authorRole: '', imageUrl: '' };

export default function AdminStoryForm({ onCreated }: { onCreated: (s: Story) => void }) {
  const [form, setForm] = useState(empty);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [saving, setSaving] = useState(false);

  function update<K extends keyof typeof form>(key: K, value: string) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setSuccess('');
    if (!form.quote.trim() || !form.authorName.trim() || !form.authorRole.trim()) {
      setError('Please fill in the quote, author name and role.');
      return;
    }
    setSaving(true);
    try {
      const story = await createStory({
        quote: form.quote.trim(),
        authorName: form.authorName.trim(),
        authorRole: form.authorRole.trim(),
        imageUrl: form.imageUrl.trim() || undefined,
      });
      setSuccess(`Story from “${story.authorName}” was added.`);
      setForm(empty);
      onCreated(story);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not create story.');
    } finally {
      setSaving(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="rounded-xl border border-gray-100 bg-white p-6 shadow-sm">
      <h2 className="text-lg font-bold text-brand-green">Add a story of change</h2>
      <p className="mt-0.5 text-sm text-gray-600">
        Saved to the database and shown on the Stories page. Leave the image blank to use a coloured
        initial avatar.
      </p>

      <div className="mt-5 space-y-4">
        <div>
          <label htmlFor="s-quote" className="block text-sm font-medium text-gray-700">Quote</label>
          <textarea
            id="s-quote"
            value={form.quote}
            onChange={(e) => update('quote', e.target.value)}
            rows={2}
            placeholder="Our new classroom has made learning so much easier and fun."
            className="mt-1 w-full rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-brand-green focus:outline-none focus:ring-1 focus:ring-brand-green"
          />
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Author name" value={form.authorName} onChange={(v) => update('authorName', v)} placeholder="Priya" />
          <Field label="Author role" value={form.authorRole} onChange={(v) => update('authorRole', v)} placeholder="Class 6, ZP School Karnataka" />
        </div>
        <Field label="Image URL (optional)" value={form.imageUrl} onChange={(v) => update('imageUrl', v)} placeholder="/images/stories/priya.png" />
      </div>

      {error && <p className="mt-4 rounded-md bg-red-50 px-3 py-2 text-sm text-red-700">{error}</p>}
      {success && <p className="mt-4 rounded-md bg-green-50 px-3 py-2 text-sm text-brand-green">{success}</p>}

      <button
        type="submit"
        disabled={saving}
        className="mt-5 rounded-md bg-brand-orange px-6 py-2.5 text-sm font-semibold text-white hover:bg-brand-orange-dark disabled:opacity-60"
      >
        {saving ? 'Saving…' : 'Add story'}
      </button>
    </form>
  );
}

function Field({
  label,
  value,
  onChange,
  placeholder,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
}) {
  return (
    <div>
      <label className="block text-sm font-medium text-gray-700">{label}</label>
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="mt-1 w-full rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-brand-green focus:outline-none focus:ring-1 focus:ring-brand-green"
      />
    </div>
  );
}
