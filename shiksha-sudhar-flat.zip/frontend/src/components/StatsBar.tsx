import type { ImpactStat } from '../types';

const statIcons: Record<string, JSX.Element> = {
  st1: (
    <path d="M3 21h18M5 21V7l7-4 7 4v14M9 9h1m4 0h1M9 13h1m4 0h1M9 17h1m4 0h1" />
  ),
  st2: (
    <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75" />
  ),
  st3: (
    <path d="M12 1v22M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6" />
  ),
  st4: (
    <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0zM12 13a3 3 0 1 0 0-6 3 3 0 0 0 0 6z" />
  ),
};

export default function StatsBar({ stats }: { stats: ImpactStat[] }) {
  return (
    <section className="bg-brand-cream">
      <div className="mx-auto grid max-w-7xl grid-cols-2 gap-6 px-6 py-5 sm:grid-cols-4">
        {stats.map((stat) => (
          <div key={stat.id} className="flex items-center gap-3 sm:justify-start">
            <span className="flex h-11 w-11 flex-shrink-0 items-center justify-center rounded-full bg-white text-brand-green">
              <svg
                width="22"
                height="22"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.8"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                {statIcons[stat.id]}
              </svg>
            </span>
            <div>
              <p className="text-2xl font-semibold text-brand-green">{stat.value}</p>
              <p className="text-sm text-gray-600">{stat.label}</p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
