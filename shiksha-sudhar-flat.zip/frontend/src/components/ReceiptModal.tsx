import { useState } from 'react';
import { submitDonationPan, receiptUrl } from '../lib/api';

interface Props {
  donationId: string;
  hasPan: boolean;
  onClose: () => void;
}

const PAN_REGEX = /^[A-Z]{5}[0-9]{4}[A-Z]$/;

export default function ReceiptModal({ donationId, hasPan, onClose }: Props) {
  const [step, setStep] = useState<'ask' | 'pan'>('ask');
  const [pan, setPan] = useState('');
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  function openReceipt() {
    window.open(receiptUrl(donationId), '_blank', 'noopener,noreferrer');
    onClose();
  }

  function onWantReceipt() {
    if (hasPan) openReceipt();
    else setStep('pan');
  }

  async function onSubmitPan(e: React.FormEvent) {
    e.preventDefault();
    const value = pan.toUpperCase().trim();
    if (!PAN_REGEX.test(value)) {
      setError('Enter a valid PAN (e.g. ABCDE1234F).');
      return;
    }
    setSaving(true);
    setError('');
    try {
      await submitDonationPan(donationId, value);
      openReceipt();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not save PAN.');
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/50 p-4">
      <div className="w-full max-w-md rounded-2xl bg-white p-6 shadow-xl">
        <div className="flex justify-center">
          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-green-100 text-brand-green">
            <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M20 6L9 17l-5-5" />
            </svg>
          </div>
        </div>
        <h2 className="mt-4 text-center text-xl font-bold text-brand-green">Thank you for your donation!</h2>
        <p className="mt-1 text-center text-sm text-gray-600">
          Your payment was successful. Would you like an 80G tax-exemption receipt?
        </p>

        {step === 'ask' ? (
          <div className="mt-6 flex flex-col gap-3 sm:flex-row">
            <button
              onClick={onWantReceipt}
              className="flex-1 rounded-md bg-brand-orange px-4 py-2.5 text-sm font-semibold text-white hover:bg-brand-orange-dark"
            >
              Generate 80G receipt
            </button>
            <button
              onClick={onClose}
              className="flex-1 rounded-md border border-gray-300 px-4 py-2.5 text-sm font-semibold text-gray-700 hover:bg-gray-50"
            >
              No, thanks
            </button>
          </div>
        ) : (
          <form onSubmit={onSubmitPan} className="mt-6">
            <label className="block text-sm font-medium text-gray-700" htmlFor="pan">
              PAN (required for 80G)
            </label>
            <input
              id="pan"
              value={pan}
              onChange={(e) => setPan(e.target.value.toUpperCase())}
              maxLength={10}
              placeholder="ABCDE1234F"
              className="mt-1 w-full rounded-md border border-gray-300 px-3 py-2 text-sm uppercase tracking-wider focus:border-brand-green focus:outline-none focus:ring-1 focus:ring-brand-green"
            />
            {error && <p className="mt-2 text-sm text-red-600">{error}</p>}
            <div className="mt-4 flex gap-3">
              <button
                type="submit"
                disabled={saving}
                className="flex-1 rounded-md bg-brand-orange px-4 py-2.5 text-sm font-semibold text-white hover:bg-brand-orange-dark disabled:opacity-60"
              >
                {saving ? 'Saving…' : 'Get receipt'}
              </button>
              <button
                type="button"
                onClick={onClose}
                className="rounded-md border border-gray-300 px-4 py-2.5 text-sm font-semibold text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
