import { Link } from 'react-router-dom';
import type { Partner } from '../types';

export function Partners({ partners }: { partners: Partner[] }) {
  return (
    <section className="mx-auto max-w-7xl px-6 py-9">
      <h2 className="text-2xl font-bold text-brand-green sm:text-3xl">Our Partners</h2>
      <p className="mt-1 text-sm text-gray-600">
        We collaborate with corporates, foundations and individuals to build stronger, more
        equitable communities.
      </p>
      <div className="mt-6 grid grid-cols-2 items-center gap-y-4 sm:grid-cols-4 lg:grid-cols-7">
        {partners.map((partner, i) => (
          <div
            key={partner.id}
            className={`flex items-center justify-center px-4 ${
              i !== 0 ? 'lg:border-l lg:border-gray-200' : ''
            }`}
          >
            {partner.logoUrl ? (
              <img
                src={partner.logoUrl}
                alt={partner.name}
                className="max-h-8 w-auto object-contain opacity-70 grayscale transition hover:opacity-100 hover:grayscale-0"
              />
            ) : (
              <span className="text-center text-base font-bold tracking-tight text-gray-400 transition hover:text-brand-green">
                {partner.name}
              </span>
            )}
          </div>
        ))}
      </div>
    </section>
  );
}

export function CTABanner() {
  return (
    <section
      id="donate"
      style={{ backgroundImage: 'linear-gradient(to right, #2E6650, #1C4A39, #12332A)' }}
    >
      <div className="relative mx-auto flex max-w-7xl flex-col items-center gap-3 px-6 py-6 sm:flex-row sm:justify-between">
        <div className="text-center sm:absolute sm:inset-x-0 sm:text-center">
          <p className="text-xl font-bold text-white">
            Together, we can build a brighter, more equal India.
          </p>
          <p className="mt-1 text-sm text-white/70">
            Support school development projects and help create lasting change.
          </p>
        </div>
        <Link
          to="/donate"
          className="relative z-10 ml-auto inline-flex items-center gap-2 whitespace-nowrap rounded-md bg-brand-orange px-6 py-3 text-sm font-semibold text-white shadow-sm transition hover:bg-brand-orange-dark"
        >
          Donate Now <span aria-hidden>→</span>
        </Link>
      </div>
    </section>
  );
}
