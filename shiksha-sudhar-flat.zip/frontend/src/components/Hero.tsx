import { Link } from 'react-router-dom';

const trustPoints = [
  {
    label: 'Trusted non-profit',
    icon: <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75" />,
  },
  {
    label: '80G tax benefits',
    icon: <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10zM9 12l2 2 4-4" />,
  },
  {
    label: '100% transparent funds',
    icon: <path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1-1a5.5 5.5 0 0 0-7.8 7.8l1 1 7.8 7.8 7.8-7.8 1-1a5.5 5.5 0 0 0 0-7.8z" />,
  },
];

export default function Hero() {
  return (
    <section className="relative overflow-hidden">
      <img
        src="/images/homepagebanner.png"
        alt="Indian schoolchildren in blue uniforms smiling in front of their school"
        className="absolute inset-0 h-full w-full object-cover"
      />
      <div className="absolute inset-0 bg-gradient-to-r from-white from-10% via-white/60 via-35% to-transparent to-55%" />

      <div className="relative mx-auto max-w-7xl px-6 py-20 sm:py-28 lg:py-36">
        <div className="max-w-xl">
          <p className="text-xs font-semibold uppercase tracking-wider text-gray-600">
            Quality education for every child
          </p>
          <h1 className="mt-3 text-5xl font-extrabold leading-[1.05] tracking-tight text-brand-green sm:text-6xl">
            Stronger Schools.
            <br />
            <span className="text-brand-orange">Brighter Futures.</span>
          </h1>
          <p className="mt-5 max-w-md text-base leading-relaxed text-gray-700">
            We support school development projects across India to create safe, inclusive
            and high-quality learning environments for every child.
          </p>

          <div className="mt-7 flex flex-wrap gap-3">
            <Link
              to="/donate"
              className="inline-flex items-center gap-2 rounded-md bg-brand-orange px-6 py-3.5 text-sm font-semibold text-white shadow-sm transition hover:bg-brand-orange-dark"
            >
              Donate Now <span aria-hidden>→</span>
            </Link>
            <a
              href="#projects"
              className="rounded-md border border-gray-300 bg-white/70 px-6 py-3.5 text-sm font-semibold text-gray-700 backdrop-blur transition hover:bg-white"
            >
              Explore Projects
            </a>
          </div>

          <div className="mt-8 inline-flex flex-col divide-gray-300 rounded-xl bg-white/70 px-3 py-1.5 shadow-sm backdrop-blur sm:flex-row sm:divide-x">
            {trustPoints.map((p, i) => (
              <div
                key={p.label}
                className={`flex items-center gap-1.5 py-1.5 text-xs font-medium text-gray-700 sm:py-0 ${
                  i === 0 ? 'sm:pr-3' : 'sm:px-3'
                }`}
              >
                <svg
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="1.8"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="flex-shrink-0 text-brand-green"
                >
                  {p.icon}
                </svg>
                {p.label}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
