import { Link } from 'react-router-dom';

const outcomes = [
  { value: '95%', label: 'Schools show improved enrolment' },
  { value: '88%', label: 'Students report better learning experience' },
  { value: '76%', label: "Girls' attendance increased" },
];

export default function ImpactSection() {
  return (
    <section id="impact" className="mx-auto max-w-7xl px-6 py-9">
      <div className="grid gap-8 lg:grid-cols-3">
        <Link
          to="/impact-video"
          aria-label="Watch our impact video"
          className="group relative block overflow-hidden rounded-xl lg:col-span-1"
        >
          <img
            src="/images/VidoCover.png"
            alt="Watch our impact video"
            className="h-72 w-full object-cover transition group-hover:scale-105"
          />
          <span className="absolute inset-0 flex items-center justify-center">
            <span className="flex h-14 w-14 items-center justify-center rounded-full bg-white/90 text-brand-green shadow-lg transition group-hover:bg-white">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor">
                <path d="M8 5v14l11-7z" />
              </svg>
            </span>
          </span>
          <span className="absolute bottom-4 left-4 rounded-full bg-white/90 px-4 py-2 text-sm font-medium text-brand-green">
            ▶ Watch our impact
          </span>
        </Link>

        <div className="lg:col-span-1">
          <p className="text-sm font-medium text-brand-orange">Why support us</p>
          <h2 className="mt-2 text-2xl font-bold text-brand-green sm:text-3xl">
            Education creates opportunity
          </h2>
          <p className="mt-3 text-sm text-gray-600">
            From better classrooms to improved learning resources, see how your support is
            transforming lives across India.
          </p>
          <button className="mt-5 rounded-md border border-gray-300 px-5 py-2.5 text-sm font-medium text-gray-700 hover:bg-gray-50">
            Learn more about our work
          </button>
        </div>

        <div className="grid grid-cols-1 gap-4 lg:col-span-1">
          {outcomes.map((o) => (
            <div key={o.label} className="rounded-lg bg-brand-cream p-4">
              <p className="text-xl font-semibold text-brand-green">{o.value}</p>
              <p className="text-sm text-gray-600">{o.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
