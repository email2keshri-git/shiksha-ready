import { useEffect, useMemo, useState } from 'react';
import Modal from './Modal';
import { getProjects, createProject, updateProject, deleteProject } from '../../lib/api';
import type { Project, ProjectCategory } from '../../types';

const categories: { value: ProjectCategory; label: string }[] = [
  { value: 'INFRASTRUCTURE', label: 'Infrastructure' },
  { value: 'SANITATION', label: 'Sanitation' },
  { value: 'DIGITAL_LEARNING', label: 'Digital learning' },
  { value: 'LIBRARY', label: 'Library' },
  { value: 'SPORTS', label: 'Sports' },
  { value: 'TEACHER_TRAINING', label: 'Teacher training' },
];
const categoryLabel = Object.fromEntries(categories.map((c) => [c.value, c.label]));

function rupees(n: number) {
  return `₹${n.toLocaleString('en-IN')}`;
}

export default function AdminProjectsPanel() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState<Project | null>(null);
  const [creating, setCreating] = useState(false);

  function refresh() {
    setLoading(true);
    getProjects()
      .then(setProjects)
      .finally(() => setLoading(false));
  }
  useEffect(refresh, []);

  const kpis = useMemo(() => {
    const totalRaised = projects.reduce((s, p) => s + p.raisedAmount, 0);
    const totalDonors = projects.reduce((s, p) => s + (p.donorCount ?? 0), 0);
    return { totalRaised, totalDonors, active: projects.length };
  }, [projects]);

  async function handleDelete(p: Project) {
    if (!window.confirm(`Delete “${p.title}”? This cannot be undone.`)) return;
    await deleteProject(p.id);
    refresh();
  }

  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-gray-900">Projects</h1>
          <p className="text-sm text-gray-600">Manage school development projects.</p>
        </div>
        <button
          onClick={() => setCreating(true)}
          className="inline-flex items-center gap-2 rounded-md bg-brand-orange px-4 py-2 text-sm font-semibold text-white hover:bg-brand-orange-dark"
        >
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round">
            <path d="M12 5v14M5 12h14" />
          </svg>
          New project
        </button>
      </div>

      <div className="mb-6 grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Kpi label="Total raised" value={rupees(kpis.totalRaised)} />
        <Kpi label="Active projects" value={String(kpis.active)} />
        <Kpi label="Total donors" value={kpis.totalDonors.toLocaleString('en-IN')} />
        <Kpi label="Schools supported" value="1,250+" />
      </div>

      <div className="overflow-x-auto rounded-xl border border-gray-100 bg-white">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-gray-100 text-left text-gray-500">
              <th className="px-4 py-3 font-medium">Project</th>
              <th className="px-4 py-3 font-medium">Category</th>
              <th className="px-4 py-3 font-medium">Progress</th>
              <th className="px-4 py-3 font-medium">Status</th>
              <th className="px-4 py-3 text-right font-medium">Actions</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr><td colSpan={5} className="px-4 py-6 text-gray-500">Loading…</td></tr>
            ) : projects.length === 0 ? (
              <tr><td colSpan={5} className="px-4 py-6 text-gray-500">No projects yet.</td></tr>
            ) : (
              projects.map((p) => (
                <tr key={p.id} className="border-b border-gray-50 last:border-0">
                  <td className="px-4 py-3">
                    <p className="font-medium text-gray-900">{p.title}</p>
                    <p className="text-xs text-gray-500">{p.school}</p>
                  </td>
                  <td className="px-4 py-3 text-gray-600">{categoryLabel[p.category]}</td>
                  <td className="px-4 py-3 font-medium text-brand-green">{p.progress}%</td>
                  <td className="px-4 py-3">
                    <span className="rounded-full bg-green-100 px-2.5 py-0.5 text-xs font-medium text-green-700">
                      Active
                    </span>
                  </td>
                  <td className="px-4 py-3 text-right">
                    <button
                      onClick={() => setEditing(p)}
                      aria-label="Edit"
                      className="mr-3 text-gray-400 hover:text-brand-green"
                    >
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M12 20h9M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z" />
                      </svg>
                    </button>
                    <button
                      onClick={() => handleDelete(p)}
                      aria-label="Delete"
                      className="text-gray-400 hover:text-red-600"
                    >
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14" />
                      </svg>
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {(creating || editing) && (
        <ProjectFormModal
          project={editing}
          onClose={() => {
            setCreating(false);
            setEditing(null);
          }}
          onSaved={() => {
            setCreating(false);
            setEditing(null);
            refresh();
          }}
        />
      )}
    </div>
  );
}

function Kpi({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl border border-gray-100 bg-brand-cream p-4">
      <p className="text-xs text-gray-500">{label}</p>
      <p className="mt-1 text-xl font-bold text-brand-green">{value}</p>
    </div>
  );
}

function ProjectFormModal({
  project,
  onClose,
  onSaved,
}: {
  project: Project | null;
  onClose: () => void;
  onSaved: () => void;
}) {
  const isEdit = Boolean(project);
  const [form, setForm] = useState({
    title: project?.title ?? '',
    school: project?.school ?? '',
    category: (project?.category ?? 'INFRASTRUCTURE') as ProjectCategory,
    goalAmount: project ? String(project.goalAmount) : '',
    description: project?.description ?? '',
    imageUrl: project?.imageUrl ?? '',
  });
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  function set<K extends keyof typeof form>(k: K, v: (typeof form)[K]) {
    setForm((f) => ({ ...f, [k]: v }));
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    const goal = Number(form.goalAmount);
    if (!form.title.trim() || !form.description.trim() || !form.school.trim()) {
      setError('Please fill in title, school and description.');
      return;
    }
    if (!goal || goal <= 0) {
      setError('Funding goal must be a positive number (in rupees).');
      return;
    }
    setSaving(true);
    try {
      if (isEdit && project) {
        await updateProject(project.id, {
          title: form.title.trim(),
          description: form.description.trim(),
          category: form.category,
          imageUrl: form.imageUrl.trim(),
          goalAmount: Math.floor(goal),
        });
      } else {
        await createProject({
          title: form.title.trim(),
          description: form.description.trim(),
          category: form.category,
          imageUrl: form.imageUrl.trim() || '',
          goalAmount: Math.floor(goal),
          school: form.school.trim(),
        });
      }
      onSaved();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not save project.');
    } finally {
      setSaving(false);
    }
  }

  const input = 'mt-1 w-full rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-brand-green focus:outline-none focus:ring-1 focus:ring-brand-green';

  return (
    <Modal
      open
      title={isEdit ? 'Edit project' : 'Create project'}
      description={isEdit ? 'Update this school development project.' : 'Add a new school development project.'}
      onClose={onClose}
    >
      <form onSubmit={submit} className="space-y-3">
        <div>
          <label className="text-xs text-gray-600">Project title</label>
          <input value={form.title} onChange={(e) => set('title', e.target.value)} placeholder="Build 3 new classrooms" className={input} />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="text-xs text-gray-600">School</label>
            <input value={form.school} onChange={(e) => set('school', e.target.value)} placeholder="Zila Parishad School, Karnataka" className={input} />
          </div>
          <div>
            <label className="text-xs text-gray-600">Category</label>
            <select value={form.category} onChange={(e) => set('category', e.target.value as ProjectCategory)} className={input}>
              {categories.map((c) => (
                <option key={c.value} value={c.value}>{c.label}</option>
              ))}
            </select>
          </div>
        </div>
        <div>
          <label className="text-xs text-gray-600">Funding goal (₹)</label>
          <input type="number" min={1} value={form.goalAmount} onChange={(e) => set('goalAmount', e.target.value)} placeholder="1500000" className={input} />
        </div>
        <div>
          <label className="text-xs text-gray-600">Description</label>
          <textarea rows={2} value={form.description} onChange={(e) => set('description', e.target.value)} placeholder="What will this funding be used for?" className={input} />
        </div>
        <div>
          <label className="text-xs text-gray-600">Cover image URL (optional)</label>
          <input value={form.imageUrl} onChange={(e) => set('imageUrl', e.target.value)} placeholder="/images/Infrastructure.png" className={input} />
        </div>

        {error && <p className="rounded-md bg-red-50 px-3 py-2 text-sm text-red-700">{error}</p>}

        <div className="flex gap-3 pt-1">
          <button type="button" onClick={onClose} className="flex-1 rounded-md border border-gray-300 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50">
            Cancel
          </button>
          <button type="submit" disabled={saving} className="flex-1 rounded-md bg-brand-orange py-2 text-sm font-semibold text-white hover:bg-brand-orange-dark disabled:opacity-60">
            {saving ? 'Saving…' : isEdit ? 'Save changes' : 'Create project'}
          </button>
        </div>
      </form>
    </Modal>
  );
}
