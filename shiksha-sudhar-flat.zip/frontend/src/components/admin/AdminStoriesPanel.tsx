import { useEffect, useState } from 'react';
import Modal from './Modal';
import { getStories, createStory, deleteStory } from '../../lib/api';
import type { Story } from '../../types';

export default function AdminStoriesPanel() {
  const [stories, setStories] = useState<Story[]>([]);
  const [loading, setLoading] = useState(true);
  const [adding, setAdding] = useState(false);

  function refresh() {
    setLoading(true);
    getStories()
      .then(setStories)
      .finally(() => setLoading(false));
  }
  useEffect(refresh, []);

  async function handleDelete(s: Story) {
    if (!window.confirm(`Delete the story from “${s.authorName}”?`)) return;
    await deleteStory(s.id);
    refresh();
  }

  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-gray-900">Stories</h1>
          <p className="text-sm text-gray-600">Manage stories of change.</p>
        </div>
        <button onClick={() => setAdding(true)} className="inline-flex items-center gap-2 rounded-md bg-brand-orange px-4 py-2 text-sm font-semibold text-white hover:bg-brand-orange-dark">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round"><path d="M12 5v14M5 12h14" /></svg>
          New story
        </button>
      </div>

      <div className="overflow-x-auto rounded-xl border border-gray-100 bg-white">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-gray-100 text-left text-gray-500">
              <th className="px-4 py-3 font-medium">Author</th>
              <th className="px-4 py-3 font-medium">Quote</th>
              <th className="px-4 py-3 text-right font-medium">Actions</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr><td colSpan={3} className="px-4 py-6 text-gray-500">Loading…</td></tr>
            ) : stories.length === 0 ? (
              <tr><td colSpan={3} className="px-4 py-6 text-gray-500">No stories yet.</td></tr>
            ) : (
              stories.map((s) => (
                <tr key={s.id} className="border-b border-gray-50 last:border-0">
                  <td className="px-4 py-3">
                    <p className="font-medium text-gray-900">{s.authorName}</p>
                    <p className="text-xs text-gray-500">{s.authorRole}</p>
                  </td>
                  <td className="max-w-md px-4 py-3 text-gray-600">
                    <span className="line-clamp-2">{s.quote}</span>
                  </td>
                  <td className="px-4 py-3 text-right">
                    <button onClick={() => handleDelete(s)} aria-label="Delete" className="text-gray-400 hover:text-red-600">
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14" /></svg>
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {adding && <StoryFormModal onClose={() => setAdding(false)} onSaved={() => { setAdding(false); refresh(); }} />}
    </div>
  );
}

function StoryFormModal({ onClose, onSaved }: { onClose: () => void; onSaved: () => void }) {
  const [form, setForm] = useState({ quote: '', authorName: '', authorRole: '', imageUrl: '' });
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);
  const input = 'mt-1 w-full rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-brand-green focus:outline-none focus:ring-1 focus:ring-brand-green';

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    if (!form.quote.trim() || !form.authorName.trim() || !form.authorRole.trim()) {
      setError('Please fill in the quote, author name and role.');
      return;
    }
    setSaving(true);
    try {
      await createStory({
        quote: form.quote.trim(),
        authorName: form.authorName.trim(),
        authorRole: form.authorRole.trim(),
        imageUrl: form.imageUrl.trim() || undefined,
      });
      onSaved();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not create story.');
    } finally {
      setSaving(false);
    }
  }

  return (
    <Modal open title="Add story" description="Add a new story of change." onClose={onClose}>
      <form onSubmit={submit} className="space-y-3">
        <div>
          <label className="text-xs text-gray-600">Quote</label>
          <textarea rows={2} value={form.quote} onChange={(e) => setForm((f) => ({ ...f, quote: e.target.value }))} className={input} />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="text-xs text-gray-600">Author name</label>
            <input value={form.authorName} onChange={(e) => setForm((f) => ({ ...f, authorName: e.target.value }))} className={input} />
          </div>
          <div>
            <label className="text-xs text-gray-600">Author role</label>
            <input value={form.authorRole} onChange={(e) => setForm((f) => ({ ...f, authorRole: e.target.value }))} className={input} />
          </div>
        </div>
        <div>
          <label className="text-xs text-gray-600">Image URL (optional)</label>
          <input value={form.imageUrl} onChange={(e) => setForm((f) => ({ ...f, imageUrl: e.target.value }))} className={input} />
        </div>
        {error && <p className="rounded-md bg-red-50 px-3 py-2 text-sm text-red-700">{error}</p>}
        <div className="flex gap-3 pt-1">
          <button type="button" onClick={onClose} className="flex-1 rounded-md border border-gray-300 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50">Cancel</button>
          <button type="submit" disabled={saving} className="flex-1 rounded-md bg-brand-orange py-2 text-sm font-semibold text-white hover:bg-brand-orange-dark disabled:opacity-60">{saving ? 'Saving…' : 'Add story'}</button>
        </div>
      </form>
    </Modal>
  );
}
