import { useEffect, useState } from 'react';
import Modal from './Modal';
import { getPartners, createPartner, deletePartner } from '../../lib/api';
import type { Partner } from '../../types';

export default function AdminPartnersPanel() {
  const [partners, setPartners] = useState<Partner[]>([]);
  const [loading, setLoading] = useState(true);
  const [adding, setAdding] = useState(false);

  function refresh() {
    setLoading(true);
    getPartners()
      .then(setPartners)
      .finally(() => setLoading(false));
  }
  useEffect(refresh, []);

  async function handleDelete(p: Partner) {
    if (!window.confirm(`Remove partner “${p.name}”?`)) return;
    await deletePartner(p.id);
    refresh();
  }

  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-gray-900">Partners</h1>
          <p className="text-sm text-gray-600">Manage corporate and foundation partners.</p>
        </div>
        <button onClick={() => setAdding(true)} className="inline-flex items-center gap-2 rounded-md bg-brand-orange px-4 py-2 text-sm font-semibold text-white hover:bg-brand-orange-dark">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round"><path d="M12 5v14M5 12h14" /></svg>
          New partner
        </button>
      </div>

      <div className="overflow-x-auto rounded-xl border border-gray-100 bg-white">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-gray-100 text-left text-gray-500">
              <th className="px-4 py-3 font-medium">Name</th>
              <th className="px-4 py-3 font-medium">Logo</th>
              <th className="px-4 py-3 text-right font-medium">Actions</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr><td colSpan={3} className="px-4 py-6 text-gray-500">Loading…</td></tr>
            ) : partners.length === 0 ? (
              <tr><td colSpan={3} className="px-4 py-6 text-gray-500">No partners yet.</td></tr>
            ) : (
              partners.map((p) => (
                <tr key={p.id} className="border-b border-gray-50 last:border-0">
                  <td className="px-4 py-3 font-medium text-gray-900">{p.name}</td>
                  <td className="px-4 py-3 text-gray-500">{p.logoUrl ? 'Image' : '—'}</td>
                  <td className="px-4 py-3 text-right">
                    <button onClick={() => handleDelete(p)} aria-label="Delete" className="text-gray-400 hover:text-red-600">
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14" /></svg>
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {adding && <PartnerFormModal onClose={() => setAdding(false)} onSaved={() => { setAdding(false); refresh(); }} />}
    </div>
  );
}

function PartnerFormModal({ onClose, onSaved }: { onClose: () => void; onSaved: () => void }) {
  const [name, setName] = useState('');
  const [logoUrl, setLogoUrl] = useState('');
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);
  const input = 'mt-1 w-full rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-brand-green focus:outline-none focus:ring-1 focus:ring-brand-green';

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    if (!name.trim()) {
      setError('Please enter a partner name.');
      return;
    }
    setSaving(true);
    try {
      await createPartner({ name: name.trim(), logoUrl: logoUrl.trim() || undefined });
      onSaved();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not add partner.');
    } finally {
      setSaving(false);
    }
  }

  return (
    <Modal open title="Add partner" description="Add a corporate or foundation partner." onClose={onClose}>
      <form onSubmit={submit} className="space-y-3">
        <div>
          <label className="text-xs text-gray-600">Partner name</label>
          <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Reliance Foundation" className={input} />
        </div>
        <div>
          <label className="text-xs text-gray-600">Logo URL (optional)</label>
          <input value={logoUrl} onChange={(e) => setLogoUrl(e.target.value)} placeholder="/images/partners/reliance.png" className={input} />
        </div>
        {error && <p className="rounded-md bg-red-50 px-3 py-2 text-sm text-red-700">{error}</p>}
        <div className="flex gap-3 pt-1">
          <button type="button" onClick={onClose} className="flex-1 rounded-md border border-gray-300 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50">Cancel</button>
          <button type="submit" disabled={saving} className="flex-1 rounded-md bg-brand-orange py-2 text-sm font-semibold text-white hover:bg-brand-orange-dark disabled:opacity-60">{saving ? 'Saving…' : 'Add partner'}</button>
        </div>
      </form>
    </Modal>
  );
}
