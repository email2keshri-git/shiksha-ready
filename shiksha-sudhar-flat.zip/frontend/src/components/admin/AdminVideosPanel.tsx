import { useEffect, useState } from 'react';
import Modal from './Modal';
import { getVideos, createVideo, deleteVideo } from '../../lib/api';
import type { ImpactVideo } from '../../types';

export default function AdminVideosPanel() {
  const [videos, setVideos] = useState<ImpactVideo[]>([]);
  const [loading, setLoading] = useState(true);
  const [adding, setAdding] = useState(false);

  function refresh() {
    setLoading(true);
    getVideos()
      .then(setVideos)
      .finally(() => setLoading(false));
  }
  useEffect(refresh, []);

  async function handleDelete(v: ImpactVideo) {
    if (!v.id || !window.confirm(`Delete “${v.title}”?`)) return;
    await deleteVideo(v.id);
    refresh();
  }

  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-gray-900">Videos</h1>
          <p className="text-sm text-gray-600">Impact videos shown on the watch page. The first is featured on the home page.</p>
        </div>
        <button onClick={() => setAdding(true)} className="inline-flex items-center gap-2 rounded-md bg-brand-orange px-4 py-2 text-sm font-semibold text-white hover:bg-brand-orange-dark">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round"><path d="M12 5v14M5 12h14" /></svg>
          New video
        </button>
      </div>

      <div className="overflow-x-auto rounded-xl border border-gray-100 bg-white">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-gray-100 text-left text-gray-500">
              <th className="px-4 py-3 font-medium">Title</th>
              <th className="px-4 py-3 font-medium">Source</th>
              <th className="px-4 py-3 text-right font-medium">Actions</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr><td colSpan={3} className="px-4 py-6 text-gray-500">Loading…</td></tr>
            ) : videos.length === 0 ? (
              <tr><td colSpan={3} className="px-4 py-6 text-gray-500">No videos yet.</td></tr>
            ) : (
              videos.map((v, i) => (
                <tr key={v.id ?? i} className="border-b border-gray-50 last:border-0">
                  <td className="px-4 py-3">
                    <p className="font-medium text-gray-900">
                      {v.title}
                      {i === 0 && <span className="ml-2 rounded-full bg-brand-cream px-2 py-0.5 text-xs font-medium text-brand-green">Featured</span>}
                    </p>
                  </td>
                  <td className="max-w-xs truncate px-4 py-3 text-gray-500">
                    {/youtu\.?be/.test(v.videoUrl)
                      ? 'YouTube'
                      : /instagram\.com/.test(v.videoUrl)
                        ? 'Instagram'
                        : 'Direct URL'}
                  </td>
                  <td className="px-4 py-3 text-right">
                    <button onClick={() => handleDelete(v)} aria-label="Delete" className="text-gray-400 hover:text-red-600">
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14" /></svg>
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {adding && <VideoFormModal onClose={() => setAdding(false)} onSaved={() => { setAdding(false); refresh(); }} />}
    </div>
  );
}

function VideoFormModal({ onClose, onSaved }: { onClose: () => void; onSaved: () => void }) {
  const [form, setForm] = useState({ title: '', description: '', videoUrl: '' });
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);
  const input = 'mt-1 w-full rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-brand-green focus:outline-none focus:ring-1 focus:ring-brand-green';

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    if (!form.title.trim() || !form.videoUrl.trim()) {
      setError('Please enter a title and a video URL or link.');
      return;
    }
    setSaving(true);
    try {
      await createVideo({
        title: form.title.trim(),
        description: form.description.trim() || undefined,
        videoUrl: form.videoUrl.trim(),
      });
      onSaved();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not add video.');
    } finally {
      setSaving(false);
    }
  }

  return (
    <Modal open title="Add video" description="Paste a direct video URL (.mp4) or a YouTube / social media link." onClose={onClose}>
      <form onSubmit={submit} className="space-y-3">
        <div>
          <label className="text-xs text-gray-600">Title</label>
          <input value={form.title} onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))} placeholder="A day at a Shiksha Sudhar school" className={input} />
        </div>
        <div>
          <label className="text-xs text-gray-600">Video URL or link</label>
          <input value={form.videoUrl} onChange={(e) => setForm((f) => ({ ...f, videoUrl: e.target.value }))} placeholder="https://youtu.be/…  or  /videos/impact.mp4" className={input} />
          <p className="mt-1 text-xs text-gray-400">Supports direct .mp4 URLs and YouTube links.</p>
        </div>
        <div>
          <label className="text-xs text-gray-600">Description (optional)</label>
          <textarea rows={2} value={form.description} onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))} className={input} />
        </div>
        {error && <p className="rounded-md bg-red-50 px-3 py-2 text-sm text-red-700">{error}</p>}
        <div className="flex gap-3 pt-1">
          <button type="button" onClick={onClose} className="flex-1 rounded-md border border-gray-300 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50">Cancel</button>
          <button type="submit" disabled={saving} className="flex-1 rounded-md bg-brand-orange py-2 text-sm font-semibold text-white hover:bg-brand-orange-dark disabled:opacity-60">{saving ? 'Saving…' : 'Add video'}</button>
        </div>
      </form>
    </Modal>
  );
}
