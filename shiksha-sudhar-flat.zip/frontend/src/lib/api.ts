import type { Project, Story, Partner, ImpactStat, Organization, VolunteerOpening, ImpactVideo, ImpactContent } from '../types';
import { mockProjects, mockStories, mockPartners, mockStats } from './mockData';

const BASE_URL = import.meta.env.VITE_API_URL || '/api';

// Small helper: try the real API, fall back to mock data so the frontend
// still renders something meaningful if the backend isn't running yet.
async function safeFetch<T>(path: string, fallback: T): Promise<T> {
  try {
    const res = await fetch(`${BASE_URL}${path}`);
    if (!res.ok) throw new Error(`Request failed: ${res.status}`);
    return await res.json();
  } catch {
    return fallback;
  }
}

export async function getFeaturedProjects(limit = 3): Promise<Project[]> {
  const data = await safeFetch<{ projects: Project[] }>(
    `/projects?featured=${limit}`,
    { projects: mockProjects }
  );
  return data.projects;
}

export async function getProjects(): Promise<Project[]> {
  const data = await safeFetch<{ projects: Project[] }>('/projects', { projects: mockProjects });
  return data.projects;
}

export async function createProject(payload: {
  title: string;
  description: string;
  category: Project['category'];
  imageUrl: string;
  goalAmount: number; // rupees
  school: string;
}): Promise<Project> {
  const res = await fetch(`${BASE_URL}/projects`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    credentials: 'include',
    body: JSON.stringify(payload),
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    const detail = (body as { details?: { message: string }[] }).details?.[0]?.message;
    throw new Error(detail || (body as { error?: string }).error || 'Could not create project.');
  }
  const data = (await res.json()) as { project: Project };
  return data.project;
}

export async function updateProject(
  id: string,
  payload: Partial<{
    title: string;
    description: string;
    category: Project['category'];
    imageUrl: string;
    goalAmount: number; // rupees
    isActive: boolean;
  }>
): Promise<Project> {
  const res = await fetch(`${BASE_URL}/projects/${id}`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    credentials: 'include',
    body: JSON.stringify(payload),
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    const detail = (body as { details?: { message: string }[] }).details?.[0]?.message;
    throw new Error(detail || (body as { error?: string }).error || 'Could not update project.');
  }
  const data = (await res.json()) as { project: Project };
  return data.project;
}

export async function deleteProject(id: string): Promise<void> {
  const res = await fetch(`${BASE_URL}/projects/${id}`, { method: 'DELETE', credentials: 'include' });
  if (!res.ok) throw new Error('Could not delete project.');
}

export async function deleteStory(id: string): Promise<void> {
  const res = await fetch(`${BASE_URL}/stories/${id}`, { method: 'DELETE', credentials: 'include' });
  if (!res.ok) throw new Error('Could not delete story.');
}

export async function deletePartner(id: string): Promise<void> {
  const res = await fetch(`${BASE_URL}/partners/${id}`, { method: 'DELETE', credentials: 'include' });
  if (!res.ok) throw new Error('Could not delete partner.');
}

export async function getOrganization(): Promise<Organization | null> {
  try {
    const res = await fetch(`${BASE_URL}/organization`);
    if (!res.ok) throw new Error(`Request failed: ${res.status}`);
    const data = (await res.json()) as { organization: Organization };
    return data.organization;
  } catch {
    return null;
  }
}

export async function getVolunteerOpenings(): Promise<VolunteerOpening[]> {
  const data = await safeFetch<{ openings: VolunteerOpening[] }>('/volunteer-openings', {
    openings: [],
  });
  return data.openings;
}

export async function subscribeNewsletter(email: string) {
  const res = await fetch(`${BASE_URL}/newsletter/subscribe`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email }),
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error((body as { error?: string }).error || 'Could not subscribe.');
  }
  return res.json() as Promise<{ success: boolean }>;
}

export async function getImpactVideo(): Promise<ImpactVideo | null> {
  try {
    const res = await fetch(`${BASE_URL}/impact-video`);
    if (!res.ok) throw new Error(`Request failed: ${res.status}`);
    const data = (await res.json()) as { video: ImpactVideo };
    return data.video;
  } catch {
    return null;
  }
}

export async function getVideos(): Promise<ImpactVideo[]> {
  try {
    const res = await fetch(`${BASE_URL}/videos`);
    if (!res.ok) throw new Error(`Request failed: ${res.status}`);
    const data = (await res.json()) as { videos: ImpactVideo[] };
    return data.videos;
  } catch {
    return [];
  }
}

export async function createVideo(payload: {
  title: string;
  description?: string;
  videoUrl: string;
}): Promise<ImpactVideo> {
  const res = await fetch(`${BASE_URL}/videos`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    credentials: 'include',
    body: JSON.stringify(payload),
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    const detail = (body as { details?: { message: string }[] }).details?.[0]?.message;
    throw new Error(detail || (body as { error?: string }).error || 'Could not add video.');
  }
  const data = (await res.json()) as { video: ImpactVideo };
  return data.video;
}

export async function deleteVideo(id: string): Promise<void> {
  const res = await fetch(`${BASE_URL}/videos/${id}`, { method: 'DELETE', credentials: 'include' });
  if (!res.ok) throw new Error('Could not delete video.');
}

export async function getStories(): Promise<Story[]> {
  const data = await safeFetch<{ stories: Story[] }>('/stories', { stories: mockStories });
  return data.stories;
}

export async function getFeaturedStories(limit = 3): Promise<Story[]> {
  const data = await safeFetch<{ stories: Story[] }>(`/stories?featured=${limit}`, {
    stories: mockStories.slice(0, limit),
  });
  return data.stories;
}

export async function createStory(payload: {
  quote: string;
  authorName: string;
  authorRole: string;
  imageUrl?: string;
}): Promise<Story> {
  const res = await fetch(`${BASE_URL}/stories`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    credentials: 'include',
    body: JSON.stringify(payload),
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    const detail = (body as { details?: { message: string }[] }).details?.[0]?.message;
    throw new Error(detail || (body as { error?: string }).error || 'Could not create story.');
  }
  const data = (await res.json()) as { story: Story };
  return data.story;
}

export async function getPartners(): Promise<Partner[]> {
  const data = await safeFetch<{ partners: Partner[] }>('/partners', { partners: mockPartners });
  return data.partners;
}

export async function createPartner(payload: { name: string; logoUrl?: string }): Promise<Partner> {
  const res = await fetch(`${BASE_URL}/partners`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    credentials: 'include',
    body: JSON.stringify(payload),
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    const detail = (body as { details?: { message: string }[] }).details?.[0]?.message;
    throw new Error(detail || (body as { error?: string }).error || 'Could not add partner.');
  }
  const data = (await res.json()) as { partner: Partner };
  return data.partner;
}

export async function getStats(): Promise<ImpactStat[]> {
  const data = await safeFetch<{ stats: ImpactStat[] }>('/stats', { stats: mockStats });
  return data.stats;
}

export async function getImpact(): Promise<ImpactContent | null> {
  try {
    const res = await fetch(`${BASE_URL}/impact`);
    if (!res.ok) throw new Error(`Request failed: ${res.status}`);
    const data = (await res.json()) as { impact: ImpactContent };
    return data.impact;
  } catch {
    return null;
  }
}

export async function createDonationOrder(payload: {
  projectId?: string;
  amount: number;
  donorName: string;
  donorEmail: string;
  donorPhone?: string;
  panNumber?: string;
  isAnonymous?: boolean;
  message?: string;
}) {
  const res = await fetch(`${BASE_URL}/donations/order`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  if (!res.ok) throw new Error('Could not start donation. Try again.');
  return res.json() as Promise<DonationOrder>;
}

export interface DonationOrder {
  donationId: string;
  orderId: string;
  amount: number; // paise
  currency: string;
  keyId: string | null;
  demoMode: boolean;
}

export async function verifyDonation(payload: {
  donationId: string;
  razorpay_order_id: string;
  razorpay_payment_id: string;
  razorpay_signature: string;
}) {
  const res = await fetch(`${BASE_URL}/donations/verify`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  if (!res.ok) throw new Error('Payment verification failed.');
  return res.json() as Promise<{ success: boolean; donationId: string }>;
}

export async function submitDonationPan(donationId: string, panNumber: string) {
  const res = await fetch(`${BASE_URL}/donations/${donationId}/pan`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ panNumber }),
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.error || 'Could not save PAN.');
  }
  return res.json() as Promise<{ success: boolean; donationId: string }>;
}

export function receiptUrl(donationId: string) {
  return `${BASE_URL}/donations/${donationId}/receipt`;
}
