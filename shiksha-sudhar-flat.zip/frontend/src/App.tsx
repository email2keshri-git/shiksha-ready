import { Routes, Route } from 'react-router-dom';
import Home from './pages/Home';
import DonatePage from './pages/DonatePage';
import AboutPage from './pages/AboutPage';
import ProjectsPage from './pages/ProjectsPage';
import GetInvolvedPage from './pages/GetInvolvedPage';
import StoriesPage from './pages/StoriesPage';
import ImpactPage from './pages/ImpactPage';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import AdminPage from './pages/AdminPage';
import ImpactVideoPage from './pages/ImpactVideoPage';
import RequireAdmin from './components/RequireAdmin';

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/about" element={<AboutPage />} />
      <Route path="/projects" element={<ProjectsPage />} />
      <Route path="/get-involved" element={<GetInvolvedPage />} />
      <Route path="/stories" element={<StoriesPage />} />
      <Route path="/impact" element={<ImpactPage />} />
      <Route path="/impact-video" element={<ImpactVideoPage />} />
      <Route path="/donate" element={<DonatePage />} />
      <Route path="/login" element={<LoginPage />} />
      <Route path="/register" element={<RegisterPage />} />
      <Route
        path="/admin"
        element={
          <RequireAdmin>
            <AdminPage />
          </RequireAdmin>
        }
      />
    </Routes>
  );
}
