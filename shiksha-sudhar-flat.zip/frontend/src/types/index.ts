export type ProjectCategory =
  | 'INFRASTRUCTURE'
  | 'SANITATION'
  | 'DIGITAL_LEARNING'
  | 'LIBRARY'
  | 'SPORTS'
  | 'TEACHER_TRAINING';

export interface Project {
  id: string;
  title: string;
  description: string;
  category: ProjectCategory;
  imageUrl: string;
  goalAmount: number; // rupees
  raisedAmount: number; // rupees
  progress: number; // 0-100
  donorCount?: number;
  school: string;
}

export interface Story {
  id: string;
  quote: string;
  authorName: string;
  authorRole: string;
  imageUrl: string;
}

export interface Partner {
  id: string;
  name: string;
  logoUrl: string;
}

export interface ImpactStat {
  id: string;
  label: string;
  value: string;
}

export interface DonationFormValues {
  amount: number;
  donorName: string;
  donorEmail: string;
  donorPhone?: string;
  panNumber?: string;
  isAnonymous?: boolean;
  message?: string;
}

export interface Organization {
  name: string;
  tagline?: string;
  registrationNumber?: string;
  registeredUnder?: string;
  pan?: string;
  reg80G?: string;
  reg12A?: string;
  csrRegNumber?: string;
  foundedYear?: number;
  addressLine1?: string;
  addressLine2?: string;
  email?: string;
  phone?: string;
  mission?: string;
  vision?: string;
  about?: string;
}

export type UserRole = 'ADMIN' | 'NGO_STAFF' | 'DONOR';

export interface AuthUser {
  id: string;
  name: string;
  email: string;
  role: UserRole;
}

export interface VolunteerOpening {
  id: string;
  title: string;
  location: string;
  mode: string;
}

export interface ImpactVideo {
  id?: string;
  title: string;
  description?: string;
  videoUrl: string;
}

export interface ImpactContent {
  outcomes: { value: string; label: string }[];
  allocation: { label: string; percent: number; color: string }[];
  yearlyGrowth: { year: string; amount: number; label: string }[];
}
