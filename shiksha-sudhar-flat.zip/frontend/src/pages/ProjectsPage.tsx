import { useEffect, useMemo, useState } from 'react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import { ProjectCard } from '../components/FeaturedProjects';
import { getProjects } from '../lib/api';
import type { Project, ProjectCategory } from '../types';

const filters: { value: 'ALL' | ProjectCategory; label: string }[] = [
  { value: 'ALL', label: 'All' },
  { value: 'INFRASTRUCTURE', label: 'Infrastructure' },
  { value: 'SANITATION', label: 'Sanitation' },
  { value: 'DIGITAL_LEARNING', label: 'Digital learning' },
  { value: 'LIBRARY', label: 'Library' },
  { value: 'SPORTS', label: 'Sports' },
  { value: 'TEACHER_TRAINING', label: 'Teacher training' },
];

type SortKey = 'trending' | 'urgent' | 'newest' | 'nearly';

export default function ProjectsPage() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);

  const [category, setCategory] = useState<'ALL' | ProjectCategory>('ALL');
  const [search, setSearch] = useState('');
  const [sort, setSort] = useState<SortKey>('trending');
  const [visibleCount, setVisibleCount] = useState(3);

  useEffect(() => {
    getProjects()
      .then(setProjects)
      .finally(() => setLoading(false));
  }, []);

  // Reset paging whenever the filters change.
  useEffect(() => {
    setVisibleCount(3);
  }, [category, search, sort]);

  const visible = useMemo(() => {
    const q = search.trim().toLowerCase();
    let list = projects.filter((p) => {
      const matchesCategory = category === 'ALL' || p.category === category;
      const matchesSearch = !q || p.title.toLowerCase().includes(q) || p.school.toLowerCase().includes(q);
      return matchesCategory && matchesSearch;
    });
    if (sort === 'urgent') list = [...list].sort((a, b) => a.progress - b.progress);
    else if (sort === 'nearly') list = [...list].sort((a, b) => b.progress - a.progress);
    else if (sort === 'trending')
      list = [...list].sort(
        (a, b) => b.progress + (b.donorCount ?? 0) - (a.progress + (a.donorCount ?? 0))
      );
    // 'newest' keeps the API order (already newest-first).
    return list;
  }, [projects, category, search, sort]);

  const shown = visible.slice(0, visibleCount);

  return (
    <div className="min-h-screen bg-white">
      <Navbar />

      <header className="bg-brand-cream">
        <div className="mx-auto max-w-7xl px-6 py-14">
          <p className="text-xs font-semibold uppercase tracking-wider text-brand-orange">Projects</p>
          <h1 className="mt-2 text-4xl font-extrabold tracking-tight text-brand-green">
            School Development Projects
          </h1>
          <p className="mt-2 max-w-2xl text-gray-600">
            Browse active school development projects and support one directly. New projects are
            added regularly.
          </p>
        </div>
      </header>

      <main className="mx-auto max-w-7xl px-6 py-10">
        <div className="flex flex-wrap gap-2">
          {filters.map((f) => (
            <button
              key={f.value}
              onClick={() => setCategory(f.value)}
              className={`whitespace-nowrap rounded-md px-4 py-1.5 text-sm font-semibold transition ${
                category === f.value
                  ? 'bg-brand-orange text-white'
                  : 'border border-gray-300 text-gray-700 hover:border-brand-green'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>

        <div className="mt-4 flex flex-col gap-3 sm:flex-row sm:items-center">
          <div className="relative flex-1">
            <span className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="11" cy="11" r="7" />
                <path d="M21 21l-4.3-4.3" />
              </svg>
            </span>
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by school or title"
              className="w-full rounded-md border border-gray-300 py-2 pl-9 pr-3 text-sm focus:border-brand-green focus:outline-none focus:ring-1 focus:ring-brand-green"
            />
          </div>
          <select
            value={sort}
            onChange={(e) => setSort(e.target.value as SortKey)}
            className="rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-brand-green focus:outline-none focus:ring-1 focus:ring-brand-green sm:w-44"
          >
            <option value="trending">Trending</option>
            <option value="urgent">Most urgent</option>
            <option value="newest">Newest</option>
            <option value="nearly">Nearly funded</option>
          </select>
        </div>

        <div className="mt-8">
          {loading ? (
            <p className="text-gray-500">Loading projects…</p>
          ) : visible.length === 0 ? (
            <p className="text-gray-500">No projects match your filters.</p>
          ) : (
            <>
              <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                {shown.map((project) => (
                  <ProjectCard key={project.id} project={project} />
                ))}
              </div>
              {visibleCount < visible.length && (
                <div className="mt-8 text-center">
                  <button
                    onClick={() => setVisibleCount((n) => n + 3)}
                    className="rounded-md border border-gray-300 px-6 py-2.5 text-sm font-semibold text-brand-green transition hover:border-brand-green hover:bg-brand-cream"
                  >
                    Load more projects
                  </button>
                </div>
              )}
            </>
          )}
        </div>
      </main>

      <Footer />
    </div>
  );
}
