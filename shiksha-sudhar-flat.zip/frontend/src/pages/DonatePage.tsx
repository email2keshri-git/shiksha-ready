import { useEffect, useMemo, useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import { createDonationOrder, verifyDonation, getProjects } from '../lib/api';
import type { Project } from '../types';

declare global {
  interface Window {
    Razorpay?: new (options: Record<string, unknown>) => { open: () => void };
  }
}

const RAZORPAY_SCRIPT = 'https://checkout.razorpay.com/v1/checkout.js';
const PAN_REGEX = /^[A-Z]{5}[0-9]{4}[A-Z]$/;
// Preset amounts (rupees). Arbitrary starting values — tune later.
const PRESET_AMOUNTS = [500, 1000, 2500, 5000];

function loadRazorpay(): Promise<boolean> {
  return new Promise((resolve) => {
    if (window.Razorpay) return resolve(true);
    const script = document.createElement('script');
    script.src = RAZORPAY_SCRIPT;
    script.onload = () => resolve(true);
    script.onerror = () => resolve(false);
    document.body.appendChild(script);
  });
}

export default function DonatePage() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const preselectedProject = searchParams.get('project') || '';

  const [projects, setProjects] = useState<Project[]>([]);
  const [projectId, setProjectId] = useState(preselectedProject);
  const [amount, setAmount] = useState<number>(1000);
  const [customAmount, setCustomAmount] = useState('');
  const [donorName, setDonorName] = useState('');
  const [donorEmail, setDonorEmail] = useState('');
  const [donorPhone, setDonorPhone] = useState('');
  const [panNumber, setPanNumber] = useState('');
  const [isAnonymous, setIsAnonymous] = useState(false);
  const [message, setMessage] = useState('');

  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    getProjects().then(setProjects).catch(() => setProjects([]));
    loadRazorpay();
  }, []);

  const effectiveAmount = useMemo(() => {
    const custom = Number(customAmount);
    return customAmount && custom > 0 ? Math.floor(custom) : amount;
  }, [amount, customAmount]);

  function validate(): string | null {
    if (!effectiveAmount || effectiveAmount < 1) return 'Please enter a valid donation amount.';
    if (!donorName.trim()) return 'Please enter your name.';
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(donorEmail)) return 'Please enter a valid email.';
    if (panNumber && !PAN_REGEX.test(panNumber.toUpperCase().trim())) {
      return 'PAN looks invalid (e.g. ABCDE1234F). Leave it blank if you prefer.';
    }
    return null;
  }

  function goToSuccess(donationId: string) {
    const pan = panNumber ? '1' : '0';
    navigate(`/?donation=success&donationId=${encodeURIComponent(donationId)}&pan=${pan}`);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const validationError = validate();
    if (validationError) {
      setError(validationError);
      return;
    }
    setError('');
    setSubmitting(true);

    try {
      const order = await createDonationOrder({
        projectId: projectId || undefined,
        amount: effectiveAmount,
        donorName: donorName.trim(),
        donorEmail: donorEmail.trim(),
        donorPhone: donorPhone.trim() || undefined,
        panNumber: panNumber ? panNumber.toUpperCase().trim() : undefined,
        isAnonymous,
        message: message.trim() || undefined,
      });

      // Demo mode: no live Razorpay keys configured on the server, so we
      // confirm the (stub) payment straight away to exercise the full flow.
      if (order.demoMode || !order.keyId) {
        await verifyDonation({
          donationId: order.donationId,
          razorpay_order_id: order.orderId,
          razorpay_payment_id: `pay_demo_${Date.now()}`,
          razorpay_signature: 'demo',
        });
        goToSuccess(order.donationId);
        return;
      }

      const ok = await loadRazorpay();
      if (!ok || !window.Razorpay) {
        throw new Error('Could not load the payment gateway. Please try again.');
      }

      const rzp = new window.Razorpay({
        key: order.keyId,
        amount: order.amount,
        currency: order.currency,
        order_id: order.orderId,
        name: 'Shiksha Sudhar Foundation',
        description: 'Donation towards school development',
        prefill: { name: donorName, email: donorEmail, contact: donorPhone },
        theme: { color: '#1C4A39' },
        handler: async (response: {
          razorpay_order_id: string;
          razorpay_payment_id: string;
          razorpay_signature: string;
        }) => {
          try {
            await verifyDonation({
              donationId: order.donationId,
              razorpay_order_id: response.razorpay_order_id,
              razorpay_payment_id: response.razorpay_payment_id,
              razorpay_signature: response.razorpay_signature,
            });
            goToSuccess(order.donationId);
          } catch {
            setError('We could not verify your payment. If money was deducted, please contact us.');
            setSubmitting(false);
          }
        },
        modal: { ondismiss: () => setSubmitting(false) },
      });
      rzp.open();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Something went wrong. Please try again.');
      setSubmitting(false);
    }
  }

  return (
    <div className="min-h-screen bg-brand-cream">
      <Navbar />

      <div className="mx-auto max-w-3xl px-6 py-12">
        <Link to="/" className="text-sm font-medium text-brand-green hover:text-brand-orange">
          ← Back to home
        </Link>

        <div className="mt-4 rounded-2xl bg-white p-6 shadow-sm sm:p-8">
          <h1 className="text-3xl font-extrabold tracking-tight text-brand-green">Make a Donation</h1>
          <p className="mt-1 text-sm text-gray-600">
            Your contribution funds safe classrooms, sanitation and learning resources for children across India.
          </p>

          <form onSubmit={handleSubmit} className="mt-8 space-y-6">
            <div>
              <label className="block text-sm font-semibold text-gray-800">Choose an amount</label>
              <div className="mt-2 flex flex-wrap gap-2">
                {PRESET_AMOUNTS.map((value) => (
                  <button
                    key={value}
                    type="button"
                    onClick={() => {
                      setAmount(value);
                      setCustomAmount('');
                    }}
                    className={`rounded-md border px-4 py-2 text-sm font-semibold transition ${
                      !customAmount && amount === value
                        ? 'border-brand-green bg-brand-green text-white'
                        : 'border-gray-300 text-gray-700 hover:border-brand-green'
                    }`}
                  >
                    ₹{value.toLocaleString('en-IN')}
                  </button>
                ))}
                <div className="relative">
                  <span className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-sm text-gray-500">₹</span>
                  <input
                    type="number"
                    min={1}
                    value={customAmount}
                    onChange={(e) => setCustomAmount(e.target.value)}
                    placeholder="Other"
                    className="w-32 rounded-md border border-gray-300 py-2 pl-7 pr-3 text-sm focus:border-brand-green focus:outline-none focus:ring-1 focus:ring-brand-green"
                  />
                </div>
              </div>
            </div>

            <div>
              <label htmlFor="project" className="block text-sm font-semibold text-gray-800">
                Donate to
              </label>
              <select
                id="project"
                value={projectId}
                onChange={(e) => setProjectId(e.target.value)}
                className="mt-1 w-full rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-brand-green focus:outline-none focus:ring-1 focus:ring-brand-green"
              >
                <option value="">General Fund (where needed most)</option>
                {projects.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.title} — {p.school}
                  </option>
                ))}
              </select>
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <Field id="name" label="Full name" value={donorName} onChange={setDonorName} required />
              <Field id="email" label="Email" type="email" value={donorEmail} onChange={setDonorEmail} required />
              <Field id="phone" label="Phone (optional)" value={donorPhone} onChange={setDonorPhone} />
              <div>
                <label htmlFor="pan" className="block text-sm font-medium text-gray-700">
                  PAN (for 80G receipt)
                </label>
                <input
                  id="pan"
                  value={panNumber}
                  onChange={(e) => setPanNumber(e.target.value.toUpperCase())}
                  maxLength={10}
                  placeholder="ABCDE1234F"
                  className="mt-1 w-full rounded-md border border-gray-300 px-3 py-2 text-sm uppercase tracking-wider focus:border-brand-green focus:outline-none focus:ring-1 focus:ring-brand-green"
                />
                <p className="mt-1 text-xs text-gray-500">Optional now — you can add it after paying.</p>
              </div>
            </div>

            <div>
              <label htmlFor="message" className="block text-sm font-medium text-gray-700">
                Message (optional)
              </label>
              <textarea
                id="message"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                rows={2}
                className="mt-1 w-full rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-brand-green focus:outline-none focus:ring-1 focus:ring-brand-green"
              />
            </div>

            <label className="flex items-center gap-2 text-sm text-gray-700">
              <input
                type="checkbox"
                checked={isAnonymous}
                onChange={(e) => setIsAnonymous(e.target.checked)}
                className="h-4 w-4 rounded border-gray-300 text-brand-green focus:ring-brand-green"
              />
              Make my donation anonymous
            </label>

            {error && (
              <p className="rounded-md bg-red-50 px-3 py-2 text-sm text-red-700">{error}</p>
            )}

            <button
              type="submit"
              disabled={submitting}
              className="w-full rounded-md bg-brand-orange px-6 py-3.5 text-sm font-semibold text-white shadow-sm transition hover:bg-brand-orange-dark disabled:opacity-60"
            >
              {submitting ? 'Processing…' : `Donate ₹${effectiveAmount.toLocaleString('en-IN')}`}
            </button>
            <p className="text-center text-xs text-gray-500">
              Secure payment via Razorpay · Eligible for 80G tax benefits
            </p>
          </form>
        </div>
      </div>

      <Footer />
    </div>
  );
}

function Field({
  id,
  label,
  value,
  onChange,
  type = 'text',
  required = false,
}: {
  id: string;
  label: string;
  value: string;
  onChange: (v: string) => void;
  type?: string;
  required?: boolean;
}) {
  return (
    <div>
      <label htmlFor={id} className="block text-sm font-medium text-gray-700">
        {label}
      </label>
      <input
        id={id}
        type={type}
        value={value}
        required={required}
        onChange={(e) => onChange(e.target.value)}
        className="mt-1 w-full rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-brand-green focus:outline-none focus:ring-1 focus:ring-brand-green"
      />
    </div>
  );
}
