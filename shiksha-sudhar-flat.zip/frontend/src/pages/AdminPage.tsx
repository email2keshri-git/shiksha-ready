import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../lib/auth';
import AdminProjectsPanel from '../components/admin/AdminProjectsPanel';
import AdminStoriesPanel from '../components/admin/AdminStoriesPanel';
import AdminPartnersPanel from '../components/admin/AdminPartnersPanel';
import AdminVideosPanel from '../components/admin/AdminVideosPanel';

type Tab = 'dashboard' | 'projects' | 'donations' | 'stories' | 'partners' | 'videos' | 'settings';

const nav: { key: Tab; label: string; icon: JSX.Element }[] = [
  { key: 'dashboard', label: 'Dashboard', icon: <path d="M3 13h8V3H3zM13 21h8V3h-8zM3 21h8v-6H3z" /> },
  { key: 'projects', label: 'Projects', icon: <path d="M3 21h18M5 21V7l7-4 7 4v14" /> },
  { key: 'donations', label: 'Donations', icon: <path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1-1a5.5 5.5 0 0 0-7.8 7.8l8.8 8.8 8.8-8.8a5.5 5.5 0 0 0 0-7.8z" /> },
  { key: 'stories', label: 'Stories', icon: <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" /> },
  { key: 'partners', label: 'Partners', icon: <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75" /> },
  { key: 'videos', label: 'Videos', icon: <path d="M23 7l-7 5 7 5zM1 5h15v14H1z" /> },
  { key: 'settings', label: 'Settings', icon: <path d="M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-2.82 1.17V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 7 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 2.6 15H2.5a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9M19.4 9a1.65 1.65 0 0 1 .33-1.82l.06-.06a2 2 0 1 0-2.83-2.83l-.06.06A1.65 1.65 0 0 1 14 4.6" /> },
];

export default function AdminPage() {
  const { user, logout } = useAuth();
  const [tab, setTab] = useState<Tab>('projects');

  return (
    <div className="flex min-h-screen bg-gray-50">
      <aside className="hidden w-56 flex-col border-r border-gray-200 bg-white p-3 sm:flex">
        <Link to="/" className="mb-4 flex items-center gap-2 px-2 py-2">
          <img src="/images/logo/logo.jpg" alt="Shiksha Sudhar" className="h-8 w-8 object-contain" />
          <span className="text-sm font-bold text-brand-green">Admin</span>
        </Link>
        <nav className="flex flex-col gap-1">
          {nav.map((n) => (
            <button
              key={n.key}
              onClick={() => setTab(n.key)}
              className={`flex items-center gap-2.5 rounded-md px-3 py-2 text-sm font-medium transition ${
                tab === n.key ? 'bg-brand-green text-white' : 'text-gray-600 hover:bg-gray-100'
              }`}
            >
              <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                {n.icon}
              </svg>
              {n.label}
            </button>
          ))}
        </nav>
        <div className="mt-auto border-t border-gray-100 px-3 pt-3">
          <p className="text-xs text-gray-500">{user?.name}</p>
          <button onClick={() => logout()} className="mt-2 text-xs font-semibold text-brand-orange hover:underline">
            Log out
          </button>
        </div>
      </aside>

      <div className="flex-1">
        <div className="flex gap-2 overflow-x-auto border-b border-gray-200 bg-white px-4 py-3 sm:hidden">
          {nav.map((n) => (
            <button
              key={n.key}
              onClick={() => setTab(n.key)}
              className={`whitespace-nowrap rounded-md px-3 py-1.5 text-xs font-semibold ${
                tab === n.key ? 'bg-brand-green text-white' : 'text-gray-600'
              }`}
            >
              {n.label}
            </button>
          ))}
        </div>

        <main className="mx-auto max-w-6xl px-5 py-6">
          {tab === 'projects' && <AdminProjectsPanel />}
          {tab === 'stories' && <AdminStoriesPanel />}
          {tab === 'partners' && <AdminPartnersPanel />}
          {tab === 'videos' && <AdminVideosPanel />}
          {tab === 'dashboard' && <Dashboard name={user?.name} />}
          {tab === 'donations' && <Placeholder title="Donations" note="Donation reporting is coming soon." />}
          {tab === 'settings' && <Placeholder title="Settings" note="Organization settings are coming soon." />}
        </main>
      </div>
    </div>
  );
}

function Dashboard({ name }: { name?: string }) {
  return (
    <div>
      <h1 className="text-xl font-bold text-gray-900">Dashboard</h1>
      <p className="text-sm text-gray-600">Welcome back, {name}.</p>
      <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {[
          { label: 'Total raised', value: '₹25,95,000' },
          { label: 'Active projects', value: '6' },
          { label: 'Registered donors', value: '1' },
          { label: 'Schools supported', value: '1,250+' },
        ].map((k) => (
          <div key={k.label} className="rounded-xl border border-gray-100 bg-white p-4 shadow-sm">
            <p className="text-xs text-gray-500">{k.label}</p>
            <p className="mt-1 text-xl font-bold text-brand-green">{k.value}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

function Placeholder({ title, note }: { title: string; note: string }) {
  return (
    <div>
      <h1 className="text-xl font-bold text-gray-900">{title}</h1>
      <div className="mt-6 rounded-xl border border-dashed border-gray-300 bg-white p-10 text-center text-sm text-gray-500">
        {note}
      </div>
    </div>
  );
}
