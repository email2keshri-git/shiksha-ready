import { useEffect, useState } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import Navbar from '../components/Navbar';
import Hero from '../components/Hero';
import StatsBar from '../components/StatsBar';
import FeaturedProjects from '../components/FeaturedProjects';
import DonationGoesTo from '../components/DonationGoesTo';
import ImpactSection from '../components/ImpactSection';
import Stories from '../components/Stories';
import { Partners, CTABanner } from '../components/PartnersAndCTA';
import Footer from '../components/Footer';
import ReceiptModal from '../components/ReceiptModal';
import { getFeaturedProjects, getFeaturedStories, getPartners, getStats } from '../lib/api';
import type { Project, Story, Partner, ImpactStat } from '../types';

export default function Home() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [stories, setStories] = useState<Story[]>([]);
  const [partners, setPartners] = useState<Partner[]>([]);
  const [stats, setStats] = useState<ImpactStat[]>([]);

  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();

  const justDonated = searchParams.get('donation') === 'success';
  const donationId = searchParams.get('donationId') || '';
  const hasPan = searchParams.get('pan') === '1';

  useEffect(() => {
    getFeaturedProjects(3).then(setProjects);
    getFeaturedStories(3).then(setStories);
    getPartners().then(setPartners);
    getStats().then(setStats);
  }, []);

  function closeModal() {
    // Drop the query params so a refresh doesn't reopen the modal.
    navigate('/', { replace: true });
    setSearchParams({});
  }

  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      <Hero />
      <StatsBar stats={stats} />
      <FeaturedProjects projects={projects} />
      <DonationGoesTo />
      <ImpactSection />
      <Stories stories={stories} />
      <Partners partners={partners} />
      <CTABanner />
      <Footer />

      {justDonated && donationId && (
        <ReceiptModal donationId={donationId} hasPan={hasPan} onClose={closeModal} />
      )}
    </div>
  );
}
