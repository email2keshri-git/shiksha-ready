import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import { getVolunteerOpenings, subscribeNewsletter } from '../lib/api';
import type { VolunteerOpening } from '../types';

const icons = {
  heart: <path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1-1a5.5 5.5 0 0 0-7.8 7.8l1 1 7.8 7.8 7.8-7.8 1-1a5.5 5.5 0 0 0 0-7.8z" />,
  users: <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75" />,
  activity: <path d="M22 12h-4l-3 9L9 3l-3 9H2" />,
  building: <path d="M3 21h18M5 21V4a1 1 0 0 1 1-1h8a1 1 0 0 1 1 1v17M9 8h1m-1 4h1m4-4h1m-1 4h1M19 21V9a1 1 0 0 0-1-1h-3" />,
};

const actions = [
  { key: 'heart', color: 'text-brand-orange', title: 'Donate', desc: 'Fund a classroom, toilet block, or digital lab.', cta: 'Donate now', to: '/donate' },
  { key: 'users', color: 'text-brand-green', title: 'Volunteer', desc: 'Teach, mentor, or help run school events.', cta: 'See opportunities', to: '#openings' },
  { key: 'activity', color: 'text-brand-orange', title: 'Fundraise', desc: 'Start a campaign for your birthday or event.', cta: 'Start fundraiser', to: '/donate' },
  { key: 'building', color: 'text-brand-green', title: 'Partner with us', desc: 'CSR programs for companies and foundations.', cta: 'Explore partnership', to: '/about' },
] as const;

export default function GetInvolvedPage() {
  const [openings, setOpenings] = useState<VolunteerOpening[]>([]);
  const [email, setEmail] = useState('');
  const [status, setStatus] = useState<'idle' | 'saving' | 'done' | 'error'>('idle');
  const [message, setMessage] = useState('');

  useEffect(() => {
    getVolunteerOpenings().then(setOpenings).catch(() => setOpenings([]));
  }, []);

  async function handleSubscribe(e: React.FormEvent) {
    e.preventDefault();
    setStatus('saving');
    setMessage('');
    try {
      await subscribeNewsletter(email.trim());
      setStatus('done');
      setMessage('Thanks! You are subscribed.');
      setEmail('');
    } catch (err) {
      setStatus('error');
      setMessage(err instanceof Error ? err.message : 'Could not subscribe.');
    }
  }

  return (
    <div className="min-h-screen bg-white">
      <Navbar />

      <header className="bg-brand-cream">
        <div className="mx-auto max-w-3xl px-6 py-14 text-center">
          <p className="text-xs font-semibold uppercase tracking-wider text-brand-orange">
            Join the movement
          </p>
          <h1 className="mt-2 text-4xl font-extrabold tracking-tight text-brand-green">Get Involved</h1>
          <p className="mx-auto mt-3 max-w-xl text-gray-600">
            There are many ways to help build stronger schools across India — pick what fits you.
          </p>
        </div>
      </header>

      <main className="mx-auto max-w-7xl px-6 py-14">
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {actions.map((a) => (
            <div
              key={a.title}
              className="flex flex-col rounded-xl border border-gray-100 bg-white p-6 shadow-sm transition hover:shadow-md"
            >
              <span className={`${a.color}`}>
                <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                  {icons[a.key]}
                </svg>
              </span>
              <h3 className="mt-4 text-lg font-bold text-brand-green">{a.title}</h3>
              <p className="mt-1 flex-1 text-sm leading-relaxed text-gray-600">{a.desc}</p>
              {a.to.startsWith('#') ? (
                <a
                  href={a.to}
                  className="mt-4 rounded-md bg-brand-orange py-2.5 text-center text-sm font-semibold text-white hover:bg-brand-orange-dark"
                >
                  {a.cta}
                </a>
              ) : (
                <Link
                  to={a.to}
                  className="mt-4 rounded-md bg-brand-orange py-2.5 text-center text-sm font-semibold text-white hover:bg-brand-orange-dark"
                >
                  {a.cta}
                </Link>
              )}
            </div>
          ))}
        </div>

        <section id="openings" className="mt-14 rounded-2xl bg-brand-cream p-6 sm:p-8">
          <h2 className="text-2xl font-bold text-brand-green">Current volunteer openings</h2>
          <p className="mt-1 text-sm text-gray-600">Remote and on-site roles, ongoing.</p>

          <div className="mt-6 space-y-3">
            {openings.length === 0 ? (
              <p className="text-sm text-gray-500">No open roles right now. Please check back soon.</p>
            ) : (
              openings.map((o) => (
                <div
                  key={o.id}
                  className="flex items-center justify-between rounded-lg border border-gray-100 bg-white px-4 py-3"
                >
                  <div>
                    <p className="text-sm font-semibold text-gray-800">{o.title}</p>
                    <p className="mt-0.5 text-xs text-gray-500">
                      {o.location} · {o.mode}
                    </p>
                  </div>
                  <span className="text-gray-400" aria-hidden>
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M5 12h14M13 6l6 6-6 6" />
                    </svg>
                  </span>
                </div>
              ))
            )}
          </div>
        </section>

        <section className="mx-auto mt-14 max-w-xl rounded-2xl border border-gray-100 p-8 text-center shadow-sm">
          <h2 className="text-xl font-bold text-brand-green">Stay in the loop</h2>
          <p className="mt-1 text-sm text-gray-600">
            Get updates on new projects and impact stories.
          </p>
          <form onSubmit={handleSubscribe} className="mx-auto mt-5 flex max-w-sm gap-2">
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="name@email.com"
              className="flex-1 rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-brand-green focus:outline-none focus:ring-1 focus:ring-brand-green"
            />
            <button
              type="submit"
              disabled={status === 'saving'}
              className="whitespace-nowrap rounded-md bg-brand-orange px-5 py-2 text-sm font-semibold text-white hover:bg-brand-orange-dark disabled:opacity-60"
            >
              {status === 'saving' ? 'Subscribing…' : 'Subscribe'}
            </button>
          </form>
          {message && (
            <p className={`mt-3 text-sm ${status === 'error' ? 'text-red-600' : 'text-brand-green'}`}>
              {message}
            </p>
          )}
        </section>
      </main>

      <Footer />
    </div>
  );
}
