import { useEffect, useMemo, useRef, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import { getVideos } from '../lib/api';
import type { ImpactVideo } from '../types';

function youtubeId(url: string): string | null {
  const patterns = [/youtu\.be\/([\w-]{11})/, /[?&]v=([\w-]{11})/, /youtube\.com\/embed\/([\w-]{11})/];
  for (const p of patterns) {
    const m = url.match(p);
    if (m) return m[1];
  }
  return null;
}

// Turns an Instagram reel/post/tv link into its embeddable URL.
function instagramEmbed(url: string): string | null {
  const m = url.match(/instagram\.com\/(reel|p|tv)\/([\w-]+)/);
  return m ? `https://www.instagram.com/${m[1]}/${m[2]}/embed` : null;
}

export default function ImpactVideoPage() {
  const [videos, setVideos] = useState<ImpactVideo[]>([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState(0);
  const [searchParams] = useSearchParams();
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    getVideos().then((list) => {
      setVideos(list);
      // Open the requested video (e.g. the trending one from home), else the first.
      const wanted = searchParams.get('v');
      const idx = wanted ? list.findIndex((v) => v.id === wanted) : 0;
      setSelected(idx >= 0 ? idx : 0);
    }).finally(() => setLoading(false));
  }, [searchParams]);

  const current = videos[selected];
  const ytId = useMemo(() => (current ? youtubeId(current.videoUrl) : null), [current]);
  const igEmbed = useMemo(() => (current ? instagramEmbed(current.videoUrl) : null), [current]);

  // Autoplay the selected video (muted fallback if the browser blocks sound).
  useEffect(() => {
    const el = videoRef.current;
    if (!el) return;
    el.play().catch(() => {
      el.muted = true;
      el.play().catch(() => undefined);
    });
  }, [selected, current]);

  return (
    <div className="flex min-h-screen flex-col bg-white">
      <Navbar />

      <main className="mx-auto w-full max-w-4xl flex-1 px-6 py-10">
        <Link to="/" className="text-sm font-medium text-brand-green hover:text-brand-orange">
          ← Back to home
        </Link>

        {loading ? (
          <p className="mt-8 text-gray-500">Loading video…</p>
        ) : !current ? (
          <p className="mt-8 text-gray-500">No videos are available right now.</p>
        ) : (
          <div className="mt-4">
            <h1 className="text-2xl font-bold text-brand-green sm:text-3xl">{current.title}</h1>
            {current.description && <p className="mt-2 text-gray-600">{current.description}</p>}

            <div className="mt-6 overflow-hidden rounded-2xl bg-black shadow-sm">
              {ytId ? (
                <iframe
                  key={ytId}
                  className="aspect-video w-full"
                  src={`https://www.youtube.com/embed/${ytId}?autoplay=1&rel=0`}
                  title={current.title}
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                />
              ) : igEmbed ? (
                <iframe
                  key={igEmbed}
                  className="mx-auto aspect-[9/16] w-full max-w-sm bg-white"
                  src={igEmbed}
                  title={current.title}
                  allow="autoplay; clipboard-write; encrypted-media; picture-in-picture"
                  allowFullScreen
                  scrolling="no"
                />
              ) : (
                <video
                  ref={videoRef}
                  key={current.videoUrl}
                  className="aspect-video w-full"
                  src={current.videoUrl}
                  controls
                  autoPlay
                  playsInline
                />
              )}
            </div>

            {videos.length > 1 && (
              <section className="mt-10">
                <h2 className="text-lg font-bold text-brand-green">More videos</h2>
                <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                  {videos
                    .map((v, i) => ({ v, i }))
                    // Show Instagram videos first in the list.
                    .sort((a, b) => Number(/instagram\.com/.test(b.v.videoUrl)) - Number(/instagram\.com/.test(a.v.videoUrl)))
                    .map(({ v, i }) => (
                      <button
                        key={v.id ?? i}
                        onClick={() => setSelected(i)}
                        className={`flex gap-3 rounded-xl border p-3 text-left transition hover:shadow-md ${
                          i === selected ? 'border-brand-green bg-brand-cream' : 'border-gray-100 bg-white'
                        }`}
                      >
                        <span className="flex h-14 w-20 flex-shrink-0 items-center justify-center rounded-lg bg-brand-green/10 text-brand-green">
                          <svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M8 5v14l11-7z" />
                          </svg>
                        </span>
                        <span className="min-w-0">
                          <span className="block truncate text-sm font-semibold text-gray-900">{v.title}</span>
                          {v.description && (
                            <span className="mt-0.5 line-clamp-2 block text-xs text-gray-500">{v.description}</span>
                          )}
                        </span>
                      </button>
                    ))}
                </div>
              </section>
            )}
          </div>
        )}
      </main>

      <Footer />
    </div>
  );
}
