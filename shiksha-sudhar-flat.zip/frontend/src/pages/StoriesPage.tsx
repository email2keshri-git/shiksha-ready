import { useEffect, useState } from 'react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import { StoryCard } from '../components/Stories';
import { getStories } from '../lib/api';
import type { Story } from '../types';

export default function StoriesPage() {
  const [stories, setStories] = useState<Story[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getStories()
      .then(setStories)
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="min-h-screen bg-white">
      <Navbar />

      <header className="bg-brand-cream">
        <div className="mx-auto max-w-7xl px-6 py-14">
          <p className="text-xs font-semibold uppercase tracking-wider text-brand-orange">Stories</p>
          <h1 className="mt-2 text-4xl font-extrabold tracking-tight text-brand-green">
            Stories of Change
          </h1>
          <p className="mt-2 max-w-2xl text-gray-600">
            Real stories from the schools, students and communities your support is transforming.
          </p>
        </div>
      </header>

      <main className="mx-auto max-w-7xl px-6 py-14">
        {loading ? (
          <p className="text-gray-500">Loading stories…</p>
        ) : stories.length === 0 ? (
          <p className="text-gray-500">No stories yet. Please check back soon.</p>
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {stories.map((story) => (
              <StoryCard key={story.id} story={story} />
            ))}
          </div>
        )}
      </main>

      <Footer />
    </div>
  );
}
