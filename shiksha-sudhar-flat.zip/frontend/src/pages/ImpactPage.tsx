import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import { getStats, getImpact } from '../lib/api';
import type { ImpactStat, ImpactContent } from '../types';

export default function ImpactPage() {
  const [stats, setStats] = useState<ImpactStat[]>([]);
  const [impact, setImpact] = useState<ImpactContent | null>(null);

  useEffect(() => {
    getStats().then(setStats);
    getImpact().then(setImpact);
  }, []);

  const maxYear = impact ? Math.max(...impact.yearlyGrowth.map((y) => y.amount), 1) : 1;

  return (
    <div className="min-h-screen bg-white">
      <Navbar />

      <header className="bg-brand-cream">
        <div className="mx-auto max-w-3xl px-6 py-12 text-center">
          <p className="text-xs font-semibold uppercase tracking-wider text-brand-orange">Our impact</p>
          <h1 className="mt-2 text-4xl font-extrabold tracking-tight text-gray-900">Real change, measured</h1>
          <p className="mx-auto mt-3 max-w-xl text-gray-600">
            Every rupee is tracked from donation to classroom. Here's what your support has built so far.
          </p>
        </div>
      </header>

      {/* Headline stats */}
      <section className="mx-auto max-w-7xl px-6">
        <div className="grid grid-cols-2 divide-x divide-y divide-gray-100 overflow-hidden rounded-xl border border-gray-100 sm:grid-cols-4 sm:divide-y-0">
          {stats.map((s) => (
            <div key={s.id} className="px-4 py-6 text-center">
              <p className="text-2xl font-bold text-brand-green">{s.value}</p>
              <p className="mt-1 text-xs text-gray-600">{s.label}</p>
            </div>
          ))}
        </div>
      </section>

      <main className="mx-auto max-w-7xl px-6 py-12">
        <div className="grid gap-10 lg:grid-cols-2">
          {/* Outcomes */}
          <section>
            <h2 className="text-lg font-bold text-gray-900">Outcomes we track</h2>
            <p className="mt-1 text-sm text-gray-600">Measured across partner schools each academic year.</p>
            <div className="mt-4 space-y-2">
              {impact?.outcomes.map((o) => (
                <div key={o.label} className="flex items-center gap-3 rounded-lg bg-brand-cream px-4 py-3">
                  <span className="w-14 flex-shrink-0 text-xl font-bold text-brand-green">{o.value}</span>
                  <span className="text-sm text-gray-600">{o.label}</span>
                </div>
              ))}
            </div>
          </section>

          {/* Fund allocation */}
          <section>
            <h2 className="text-lg font-bold text-gray-900">Where funds went this year</h2>
            <p className="mt-1 text-sm text-gray-600">₹120 Cr allocated across focus areas.</p>
            <div className="mt-4 space-y-3">
              {impact?.allocation.map((a) => (
                <div key={a.label}>
                  <div className="mb-1 flex justify-between text-xs">
                    <span className="text-gray-700">{a.label}</span>
                    <span className="text-gray-500">{a.percent}%</span>
                  </div>
                  <div className="h-2 overflow-hidden rounded-full bg-gray-100">
                    <div className="h-full rounded-full" style={{ width: `${a.percent}%`, backgroundColor: a.color }} />
                  </div>
                </div>
              ))}
            </div>
          </section>
        </div>

        {/* Yearly growth bar chart */}
        <section className="mt-12">
          <h2 className="text-lg font-bold text-gray-900">Funds raised, year over year</h2>
          <div className="mt-6 flex items-end gap-6 sm:gap-10">
            {impact?.yearlyGrowth.map((y, i) => {
              const isLast = i === impact.yearlyGrowth.length - 1;
              return (
                <div key={y.year} className="flex flex-col items-center gap-2">
                  <span className="text-xs text-gray-400">{y.label}</span>
                  <div
                    className={`w-10 rounded-t-md ${isLast ? 'bg-brand-green' : 'bg-gray-200'}`}
                    style={{ height: `${(y.amount / maxYear) * 110}px` }}
                  />
                  <span className="text-xs text-gray-600">{y.year}</span>
                </div>
              );
            })}
          </div>
        </section>

        {/* CTA */}
        <section className="mt-12 rounded-2xl bg-brand-green px-6 py-8 text-center">
          <p className="text-lg font-semibold text-white">Help us grow this number next year.</p>
          <p className="mt-1 text-sm text-white/70">Every donation is tracked to the project it funds.</p>
          <Link
            to="/donate"
            className="mt-4 inline-flex items-center gap-2 rounded-md bg-brand-orange px-6 py-3 text-sm font-semibold text-white hover:bg-brand-orange-dark"
          >
            Donate now <span aria-hidden>→</span>
          </Link>
        </section>
      </main>

      <Footer />
    </div>
  );
}
