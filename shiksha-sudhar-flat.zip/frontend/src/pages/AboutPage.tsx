import { useEffect, useState } from 'react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import { getOrganization } from '../lib/api';
import type { Organization } from '../types';

export default function AboutPage() {
  const [org, setOrg] = useState<Organization | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getOrganization()
      .then(setOrg)
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="min-h-screen bg-white">
      <Navbar />

      <header className="bg-brand-cream">
        <div className="mx-auto max-w-5xl px-6 py-14">
          <p className="text-xs font-semibold uppercase tracking-wider text-brand-orange">About us</p>
          <h1 className="mt-2 text-4xl font-extrabold tracking-tight text-brand-green">
            {org?.name || 'Shiksha Sudhar Foundation'}
          </h1>
          {org?.tagline && <p className="mt-2 text-lg text-gray-600">{org.tagline}</p>}
        </div>
      </header>

      <main className="mx-auto max-w-5xl px-6 py-14">
        {loading ? (
          <p className="text-gray-500">Loading…</p>
        ) : !org ? (
          <p className="text-gray-500">Organization details are currently unavailable.</p>
        ) : (
          <div className="grid gap-12 lg:grid-cols-3">
            <div className="space-y-8 lg:col-span-2">
              {org.about && (
                <section>
                  <h2 className="text-xl font-bold text-brand-green">Who we are</h2>
                  <p className="mt-2 leading-relaxed text-gray-700">{org.about}</p>
                </section>
              )}
              {org.mission && (
                <section>
                  <h2 className="text-xl font-bold text-brand-green">Our mission</h2>
                  <p className="mt-2 leading-relaxed text-gray-700">{org.mission}</p>
                </section>
              )}
              {org.vision && (
                <section>
                  <h2 className="text-xl font-bold text-brand-green">Our vision</h2>
                  <p className="mt-2 leading-relaxed text-gray-700">{org.vision}</p>
                </section>
              )}
            </div>

            <aside className="h-fit rounded-2xl border border-gray-100 bg-brand-cream p-6">
              <h2 className="text-sm font-bold uppercase tracking-wide text-brand-green">
                Registration &amp; contact
              </h2>
              <dl className="mt-4 space-y-3 text-sm">
                <Detail label="Founded" value={org.foundedYear?.toString()} />
                <Detail label="Registration No." value={org.registrationNumber} />
                <Detail label="Registered under" value={org.registeredUnder} />
                <Detail label="PAN" value={org.pan} />
                <Detail label="80G Reg." value={org.reg80G} />
                <Detail label="12A Reg." value={org.reg12A} />
                <Detail label="CSR Reg." value={org.csrRegNumber} />
                <Detail
                  label="Address"
                  value={[org.addressLine1, org.addressLine2].filter(Boolean).join(', ')}
                />
                <Detail label="Email" value={org.email} />
                <Detail label="Phone" value={org.phone} />
              </dl>
            </aside>
          </div>
        )}
      </main>

      <Footer />
    </div>
  );
}

function Detail({ label, value }: { label: string; value?: string }) {
  if (!value) return null;
  return (
    <div>
      <dt className="text-gray-500">{label}</dt>
      <dd className="font-medium text-gray-800">{value}</dd>
    </div>
  );
}
