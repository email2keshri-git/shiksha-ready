/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        brand: {
          orange: '#E1621B',
          'orange-dark': '#C4520F',
          green: '#1C4A39',
          'green-light': '#2E6650',
          'green-dark': '#12332A',
          cream: '#F6F5F0',
        },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
      },
    },
  },
  plugins: [],
};
