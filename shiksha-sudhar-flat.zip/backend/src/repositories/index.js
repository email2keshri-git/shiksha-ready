// Single switch point: USE_MOCK_DATA=true serves in-memory stub data with
// zero database setup. Set it to false (and configure DATABASE_URL) once
// MySQL is ready — no route or frontend code needs to change either way.

const useMock = process.env.USE_MOCK_DATA === 'true';

module.exports = useMock ? require('./mockRepository') : require('./prismaRepository');

if (useMock) {
  console.log('[repo] USE_MOCK_DATA=true — serving in-memory stub data, no database required.');
}
