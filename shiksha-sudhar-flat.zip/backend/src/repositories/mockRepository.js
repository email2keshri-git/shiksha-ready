// In-memory stand-in for the database. Same function signatures as
// prismaRepository.js, so routes never need to know which one is active.
// Data resets whenever the server restarts — that's expected for stub mode.

let projects = [
  {
    id: 'p1',
    title: 'Build 3 New Classrooms',
    description: 'Help us build 3 additional classrooms to accommodate 300+ more students.',
    category: 'INFRASTRUCTURE',
    imageUrl: '/images/Infrastructure.png',
    goalAmount: 1500000 * 100,
    raisedAmount: 925000 * 100,
    isActive: true,
    school: 'Zila Parishad School, Karnataka',
    baseDonorCount: 180,
    createdAt: new Date('2026-06-01'),
  },
  {
    id: 'p2',
    title: 'Safe and Clean Toilets for Girls',
    description: 'Support the construction of separate and hygienic toilet blocks for girls.',
    category: 'SANITATION',
    imageUrl: '/images/Sanitation.png',
    goalAmount: 1000000 * 100,
    raisedAmount: 400000 * 100,
    isActive: true,
    school: 'Government School, Rajasthan',
    baseDonorCount: 130,
    createdAt: new Date('2026-06-02'),
  },
  {
    id: 'p3',
    title: 'Digital Classrooms',
    description: 'Provide computers, smart boards and digital learning tools for a better future.',
    category: 'DIGITAL_LEARNING',
    imageUrl: '/images/Digital%20learning.png',
    goalAmount: 1500000 * 100,
    raisedAmount: 1170000 * 100,
    isActive: true,
    school: 'Municipal School, Tamil Nadu',
    baseDonorCount: 240,
    createdAt: new Date('2026-06-03'),
  },
  {
    id: 'p4',
    title: 'Stock the School Library',
    description: 'Fill the library with books, shelves and reading corners for young minds.',
    category: 'LIBRARY',
    imageUrl: '', // no image -> category-coloured background on the card
    goalAmount: 500000 * 100,
    raisedAmount: 125000 * 100,
    isActive: true,
    school: 'Govt High School, Odisha',
    baseDonorCount: 30,
    createdAt: new Date('2026-06-04'),
  },
  {
    id: 'p5',
    title: 'Build a Playground',
    description: 'Create a safe playground so children can play, exercise and grow.',
    category: 'SPORTS',
    imageUrl: '',
    goalAmount: 1000000 * 100,
    raisedAmount: 550000 * 100,
    isActive: true,
    school: 'ZP School, Maharashtra',
    baseDonorCount: 70,
    createdAt: new Date('2026-06-05'),
  },
  {
    id: 'p6',
    title: 'Teacher Training Program',
    description: 'Train teachers in modern, inclusive and effective classroom methods.',
    category: 'TEACHER_TRAINING',
    imageUrl: '',
    goalAmount: 500000 * 100,
    raisedAmount: 60000 * 100,
    isActive: true,
    school: 'Govt School, Bihar',
    baseDonorCount: 15,
    createdAt: new Date('2026-06-06'),
  },
];

const stories = [
  {
    id: 's1',
    quote: 'Our new classroom has made learning so much easier and fun.',
    authorName: 'Priya',
    authorRole: 'Class 6, ZP School Karnataka',
    imageUrl: '',
  },
  {
    id: 's2',
    quote: 'The computer lab has opened a new world for us.',
    authorName: 'Arjun',
    authorRole: 'Class 8, Municipal School Tamil Nadu',
    imageUrl: '',
  },
  {
    id: 's3',
    quote: 'These facilities have brought real hope to our community.',
    authorName: 'School Teacher',
    authorRole: 'Government School, Rajasthan',
    imageUrl: '',
  },
  {
    id: 's4',
    quote: 'Clean toilets mean the girls in our village finally stay in school.',
    authorName: 'Meena',
    authorRole: 'Parent, Government School Rajasthan',
    imageUrl: '',
  },
  {
    id: 's5',
    quote: 'The new library is my favourite place — I read a book every week now.',
    authorName: 'Rahul',
    authorRole: 'Class 7, Govt High School Odisha',
    imageUrl: '',
  },
  {
    id: 's6',
    quote: 'With better training, I can finally teach the way my students deserve.',
    authorName: 'Sunita',
    authorRole: 'Teacher, Govt School Bihar',
    imageUrl: '',
  },
];

const partners = [
  { id: 'tata', name: 'TATA', logoUrl: '' },
  { id: 'infosys', name: 'Infosys', logoUrl: '' },
  { id: 'hcl', name: 'HCL', logoUrl: '' },
  { id: 'microsoft', name: 'Microsoft', logoUrl: '' },
  { id: 'google', name: 'Google', logoUrl: '' },
  { id: 'accenture', name: 'Accenture', logoUrl: '' },
  { id: 'reliance', name: 'Reliance Foundation', logoUrl: '' },
];

const stats = [
  { id: 'st1', label: 'Schools Supported', value: '1,250+' },
  { id: 'st2', label: 'Children Impacted', value: '3,50,000+' },
  { id: 'st3', label: 'Funds Raised', value: '₹120+ Crore' },
  { id: 'st4', label: 'States Across India', value: '28' },
];

// --- Impact page content (changeable, API-driven) -------------------------
// PLACEHOLDER metrics — replace with the NGO's real reported figures.
const impact = {
  outcomes: [
    { value: '95%', label: 'Schools show improved enrolment' },
    { value: '88%', label: 'Students report better learning experience' },
    { value: '76%', label: "Girls' attendance increased" },
  ],
  allocation: [
    { label: 'Classrooms & buildings', percent: 34, color: '#F3A93B' },
    { label: 'Digital education', percent: 22, color: '#7C4DDB' },
    { label: 'Clean water & sanitation', percent: 18, color: '#2E8BE0' },
    { label: 'Learning materials & libraries', percent: 14, color: '#2E9E5B' },
    { label: 'Teacher training & sports', percent: 12, color: '#1B8A8A' },
  ],
  yearlyGrowth: [
    { year: '2022', amount: 18, label: '₹18 Cr' },
    { year: '2023', amount: 27, label: '₹27 Cr' },
    { year: '2024', amount: 35, label: '₹35 Cr' },
    { year: '2025', amount: 40, label: '₹40 Cr' },
  ],
};

async function getImpact() {
  return impact;
}

const donations = new Map(); // donationId -> donation record
let nextDonationId = 1;

// --- Users (auth) ---------------------------------------------------------
// Seeded admin for local/stub mode. PLACEHOLDER credentials — change before
// any real deployment. Password below is "Admin@12345" (bcrypt-hashed here).
const { hashPasswordSync } = require('../lib/auth');
const users = [
  {
    id: 'user_admin',
    name: 'NGO Admin',
    email: 'admin@shikshasudhar.org',
    passwordHash: hashPasswordSync('Admin@12345'),
    role: 'ADMIN',
  },
];

async function getUserByEmail(email) {
  return users.find((u) => u.email === String(email).toLowerCase()) || null;
}

async function getUserById(id) {
  return users.find((u) => u.id === id) || null;
}

let nextUserId = 1;
async function createUser({ name, email, passwordHash, role }) {
  const user = { id: `user_${Date.now()}_${nextUserId++}`, name, email, passwordHash, role: role || 'DONOR' };
  users.push(user);
  return user;
}

// --- Organization / About content ----------------------------------------
// PLACEHOLDER content served to the public About page. Replace with real
// data (ideally editable via admin) — everything here is meant to change.
const organization = {
  name: 'Shiksha Sudhar Foundation',
  tagline: 'Stronger Schools. Brighter Futures.',
  registrationNumber: 'PLACEHOLDER-REG-2020-XXXX',
  registeredUnder: 'Section 8 Company / Societies Registration Act (PLACEHOLDER)',
  pan: 'AAAAA0000A',
  reg80G: 'PLACEHOLDER-80G-REG-NUMBER',
  reg12A: 'PLACEHOLDER-12A-REG-NUMBER',
  csrRegNumber: 'CSR00000000 (PLACEHOLDER)',
  foundedYear: 2020,
  addressLine1: '[PLACEHOLDER] 123 Example Road, Connaught Place',
  addressLine2: '[PLACEHOLDER] New Delhi, India - 110001',
  email: 'contact@shikshasudhar.example',
  phone: '+91 00000 00000',
  mission:
    'To ensure every child in India learns in a safe, inclusive and well-equipped school by funding critical infrastructure, sanitation and digital learning.',
  vision:
    'A country where the quality of a child\u2019s education does not depend on where they are born.',
  about:
    'Shiksha Sudhar Foundation partners with government and low-income schools across India to rebuild classrooms, provide clean sanitation, set up digital classrooms and train teachers. We work transparently, sharing exactly how every rupee is used.',
};

async function getOrganization() {
  return organization;
}

// --- Volunteer openings (changeable content) ------------------------------
// PLACEHOLDER listings — replace with real openings (ideally admin-managed).
const volunteerOpenings = [
  { id: 'vol1', title: 'Weekend teaching assistant', location: 'Karnataka', mode: 'On-site' },
  { id: 'vol2', title: 'Content and social media help', location: 'Remote', mode: 'Flexible hours' },
  { id: 'vol3', title: 'Digital literacy trainer', location: 'Tamil Nadu', mode: 'On-site' },
];

async function getVolunteerOpenings() {
  return volunteerOpenings;
}

// STUB: no persistence / email provider yet. Logs and acknowledges.
async function subscribeNewsletter(email) {
  console.log(`[newsletter] (stub) subscribe: ${email}`);
  return { email };
}

// --- Impact videos (URL-based, changeable content) ------------------------
// PLACEHOLDER videos — replace with the NGO's real video URLs. Each supports
// a direct .mp4 URL or a YouTube link. The first is the featured one.
const videos = [
  {
    id: 'v1',
    title: 'See how your support is changing schools',
    description:
      'A short look at the classrooms, libraries and children your donations are helping across India.',
    videoUrl: 'https://youtu.be/A49T5WjVW3I?si=GEfltM_eLBcHT6N1',
  },
  {
    id: 'v2',
    title: 'A day at a Shiksha Sudhar school',
    description: 'Follow students through a day in a newly rebuilt government school.',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4',
  },
  {
    id: 'v3',
    title: 'Building classrooms that last',
    description: 'How your contributions turn into safe, permanent classrooms.',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
  },
  {
    id: 'v4',
    title: 'From our Instagram',
    description: 'A quick reel from the field, shared on Instagram.',
    videoUrl: 'https://www.instagram.com/reel/DdLEhNGs5Oh/?utm_source=ig_web_button_share_sheet',
  },
];

async function getVideos() {
  return videos;
}

async function getImpactVideo() {
  return videos[0];
}

async function createVideo(data) {
  const video = {
    id: `video_${Date.now()}`,
    title: data.title,
    description: data.description || '',
    videoUrl: data.videoUrl,
  };
  videos.push(video);
  return video;
}

async function deleteVideo(id) {
  const idx = videos.findIndex((v) => v.id === id);
  if (idx === -1) return false;
  videos.splice(idx, 1);
  return true;
}

// Distinct people who have successfully donated to a project (by email),
// derived from the donations mapping. Real signal on top of the seed base.
function countLiveDonors(projectId) {
  const emails = new Set();
  for (const d of donations.values()) {
    if (d.projectId === projectId && d.status === 'SUCCESS') emails.add(d.donorEmail);
  }
  return emails.size;
}

// Attaches donorCount = seeded base + live distinct donors.
function withDonorCount(project) {
  return { ...project, donorCount: (project.baseDonorCount || 0) + countLiveDonors(project.id) };
}

async function listProjects({ category, limit } = {}) {
  let result = projects.filter((p) => p.isActive);
  if (category) result = result.filter((p) => p.category === category.toUpperCase());
  result = [...result].sort((a, b) => b.createdAt - a.createdAt);
  if (limit) result = result.slice(0, Number(limit));
  return result.map(withDonorCount);
}

async function getProject(id) {
  const project = projects.find((p) => p.id === id);
  return project ? withDonorCount(project) : null;
}

// Amounts arrive in paise; new projects start at 0 raised and active.
async function createProject(data) {
  const project = {
    id: `proj_${Date.now()}`,
    title: data.title,
    description: data.description,
    category: data.category,
    imageUrl: data.imageUrl || '',
    goalAmount: data.goalAmount,
    raisedAmount: 0,
    isActive: true,
    school: data.school,
    baseDonorCount: 0,
    createdAt: new Date(),
  };
  projects.unshift(project);
  return project;
}

async function updateProject(id, data) {
  const project = projects.find((p) => p.id === id);
  if (!project) return null;
  for (const key of ['title', 'description', 'category', 'imageUrl', 'goalAmount', 'school', 'isActive']) {
    if (data[key] !== undefined) project[key] = data[key];
  }
  return withDonorCount(project);
}

async function deleteProject(id) {
  const idx = projects.findIndex((p) => p.id === id);
  if (idx === -1) return false;
  projects.splice(idx, 1);
  return true;
}

async function createPendingDonation(data) {
  const id = `stub_don_${nextDonationId++}`;
  const donation = { id, status: 'PENDING', ...data };
  donations.set(id, donation);
  return donation;
}

async function updateDonationStatus({ donationId, status, razorpayPaymentId }) {
  const donation = donations.get(donationId);
  if (!donation) throw new Error('Donation not found');
  donation.status = status;
  donation.razorpayPaymentId = razorpayPaymentId;
  donations.set(donationId, donation);
  return donation;
}

async function incrementProjectRaised(projectId, amountPaise) {
  const project = projects.find((p) => p.id === projectId);
  if (project) project.raisedAmount += amountPaise;
}

async function getDonationById(id) {
  return donations.get(id) || null;
}

async function updateDonationPan({ donationId, panNumber }) {
  const donation = donations.get(donationId);
  if (!donation) throw new Error('Donation not found');
  donation.panNumber = panNumber;
  donations.set(donationId, donation);
  return donation;
}

async function setDonationReceiptUrl({ donationId, receiptUrl }) {
  const donation = donations.get(donationId);
  if (!donation) throw new Error('Donation not found');
  donation.receiptUrl = receiptUrl;
  donations.set(donationId, donation);
  return donation;
}

async function getStats() {
  return stats;
}

async function getStories() {
  return stories;
}

// Newest first. imageUrl optional -> card shows a coloured initial avatar.
async function createStory(data) {
  const story = {
    id: `story_${Date.now()}`,
    quote: data.quote,
    authorName: data.authorName,
    authorRole: data.authorRole,
    imageUrl: data.imageUrl || '',
  };
  stories.unshift(story);
  return story;
}

async function deleteStory(id) {
  const idx = stories.findIndex((s) => s.id === id);
  if (idx === -1) return false;
  stories.splice(idx, 1);
  return true;
}

async function getPartners() {
  return partners;
}

async function createPartner(data) {
  const partner = { id: `partner_${Date.now()}`, name: data.name, logoUrl: data.logoUrl || '' };
  partners.push(partner);
  return partner;
}

async function deletePartner(id) {
  const idx = partners.findIndex((p) => p.id === id);
  if (idx === -1) return false;
  partners.splice(idx, 1);
  return true;
}

module.exports = {
  listProjects,
  getProject,
  createProject,
  updateProject,
  deleteProject,
  createPendingDonation,
  updateDonationStatus,
  incrementProjectRaised,
  getDonationById,
  updateDonationPan,
  setDonationReceiptUrl,
  getUserByEmail,
  getUserById,
  createUser,
  getOrganization,
  getVolunteerOpenings,
  subscribeNewsletter,
  getImpactVideo,
  getVideos,
  createVideo,
  deleteVideo,
  getImpact,
  getStats,
  getStories,
  createStory,
  deleteStory,
  getPartners,
  createPartner,
  deletePartner,
};
