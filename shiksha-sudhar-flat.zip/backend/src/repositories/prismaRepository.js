// Real database implementation, backed by Prisma/MySQL. Same function
// signatures as mockRepository.js so routes work unchanged either way.

const prisma = require('../lib/prisma');

async function listProjects({ category, limit } = {}) {
  const projects = await prisma.project.findMany({
    where: {
      isActive: true,
      ...(category ? { category: String(category).toUpperCase() } : {}),
    },
    include: { school: true },
    orderBy: { createdAt: 'desc' },
    take: limit ? Number(limit) : undefined,
  });

  // Distinct successful donors per project (one groupBy for the whole page).
  const grouped = await prisma.donation.groupBy({
    by: ['projectId', 'donorEmail'],
    where: { status: 'SUCCESS', projectId: { in: projects.map((p) => p.id) } },
  });
  const liveDonors = {};
  for (const g of grouped) liveDonors[g.projectId] = (liveDonors[g.projectId] || 0) + 1;

  return projects.map((p) => ({
    ...p,
    school: `${p.school.name}, ${p.school.state}`,
    donorCount: (p.baseDonorCount || 0) + (liveDonors[p.id] || 0),
  }));
}

async function getProject(id) {
  const project = await prisma.project.findUnique({
    where: { id },
    include: { school: true },
  });
  if (!project) return null;
  const donors = await prisma.donation.groupBy({
    by: ['donorEmail'],
    where: { projectId: id, status: 'SUCCESS' },
  });
  return {
    ...project,
    school: `${project.school.name}, ${project.school.state}`,
    donorCount: (project.baseDonorCount || 0) + donors.length,
  };
}

// Amounts arrive in paise. Creates the school record from the free-text
// school field, then the project. Split "Name, State" when possible.
async function createProject(data) {
  const [name, state = ''] = String(data.school).split(',').map((s) => s.trim());
  const school = await prisma.school.create({ data: { name, state, city: state } });
  const project = await prisma.project.create({
    data: {
      title: data.title,
      description: data.description,
      category: data.category,
      imageUrl: data.imageUrl,
      goalAmount: data.goalAmount,
      raisedAmount: 0,
      isActive: true,
      schoolId: school.id,
    },
  });
  return { ...project, school: `${school.name}, ${school.state}` };
}

async function updateProject(id, data) {
  const fields = {};
  for (const key of ['title', 'description', 'category', 'imageUrl', 'goalAmount', 'isActive']) {
    if (data[key] !== undefined) fields[key] = data[key];
  }
  const project = await prisma.project.update({ where: { id }, data: fields, include: { school: true } });
  return { ...project, school: `${project.school.name}, ${project.school.state}` };
}

async function deleteProject(id) {
  await prisma.project.delete({ where: { id } });
  return true;
}

async function createPendingDonation(data) {
  return prisma.donation.create({
    data: {
      amount: data.amount,
      donorName: data.donorName,
      donorEmail: data.donorEmail,
      donorPhone: data.donorPhone,
      panNumber: data.panNumber,
      isAnonymous: data.isAnonymous ?? false,
      message: data.message,
      status: 'PENDING',
      razorpayOrderId: data.razorpayOrderId,
      projectId: data.projectId || null,
    },
  });
}

async function updateDonationStatus({ donationId, status, razorpayPaymentId }) {
  return prisma.donation.update({
    where: { id: donationId },
    data: { status, razorpayPaymentId },
  });
}

async function incrementProjectRaised(projectId, amountPaise) {
  await prisma.project.update({
    where: { id: projectId },
    data: { raisedAmount: { increment: amountPaise } },
  });
}

async function getDonationById(id) {
  return prisma.donation.findUnique({ where: { id }, include: { project: true } });
}

async function updateDonationPan({ donationId, panNumber }) {
  return prisma.donation.update({ where: { id: donationId }, data: { panNumber } });
}

async function setDonationReceiptUrl({ donationId, receiptUrl }) {
  return prisma.donation.update({ where: { id: donationId }, data: { receiptUrl } });
}

async function getUserByEmail(email) {
  return prisma.user.findUnique({ where: { email: String(email).toLowerCase() } });
}

async function getUserById(id) {
  return prisma.user.findUnique({ where: { id } });
}

async function createUser({ name, email, passwordHash, role }) {
  return prisma.user.create({ data: { name, email, passwordHash, role: role || 'DONOR' } });
}

async function getOrganization() {
  // Single-row org/about content; returns the first record.
  return prisma.organization.findFirst();
}

async function getImpactVideo() {
  return prisma.impactVideo.findFirst();
}

async function getVideos() {
  return prisma.impactVideo.findMany({ orderBy: { updatedAt: 'desc' } });
}

async function createVideo(data) {
  return prisma.impactVideo.create({
    data: { title: data.title, description: data.description || null, videoUrl: data.videoUrl },
  });
}

async function deleteVideo(id) {
  await prisma.impactVideo.delete({ where: { id } });
  return true;
}

async function getVolunteerOpenings() {
  return prisma.volunteerOpening.findMany({
    where: { isActive: true },
    orderBy: { createdAt: 'desc' },
  });
}

async function subscribeNewsletter(email) {
  return prisma.newsletterSubscriber.upsert({
    where: { email },
    update: {},
    create: { email },
  });
}

async function getStats() {
  return prisma.impactStat.findMany();
}

async function getImpact() {
  return prisma.impactContent.findFirst();
}

async function getStories() {
  return prisma.story.findMany({ orderBy: { createdAt: 'desc' } });
}

async function createStory(data) {
  return prisma.story.create({
    data: {
      quote: data.quote,
      authorName: data.authorName,
      authorRole: data.authorRole,
      imageUrl: data.imageUrl || '',
    },
  });
}

async function deleteStory(id) {
  await prisma.story.delete({ where: { id } });
  return true;
}

async function getPartners() {
  return prisma.partner.findMany();
}

async function createPartner(data) {
  return prisma.partner.create({ data: { name: data.name, logoUrl: data.logoUrl || '' } });
}

async function deletePartner(id) {
  await prisma.partner.delete({ where: { id } });
  return true;
}

module.exports = {
  listProjects,
  getProject,
  createProject,
  updateProject,
  deleteProject,
  createPendingDonation,
  updateDonationStatus,
  incrementProjectRaised,
  getDonationById,
  updateDonationPan,
  setDonationReceiptUrl,
  getUserByEmail,
  getUserById,
  createUser,
  getOrganization,
  getVolunteerOpenings,
  subscribeNewsletter,
  getImpactVideo,
  getVideos,
  createVideo,
  deleteVideo,
  getStats,
  getImpact,
  getStories,
  createStory,
  deleteStory,
  getPartners,
  createPartner,
  deletePartner,
};
