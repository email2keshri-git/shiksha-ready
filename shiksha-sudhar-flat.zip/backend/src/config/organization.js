// Organization details printed on 80G tax-exemption receipts.
//
// !!! PLACEHOLDER DATA !!! These are NOT the real registered details.
// Replace with the NGO's actual 80G registration info before going live.
// Every value is env-overridable so production can inject real values
// without any code change (set these in the backend .env).
module.exports = {
  name: process.env.ORG_NAME || 'Shiksha Sudhar Foundation',
  addressLine1: process.env.ORG_ADDRESS_LINE1 || '[PLACEHOLDER] 123 Example Road, Connaught Place',
  addressLine2: process.env.ORG_ADDRESS_LINE2 || '[PLACEHOLDER] New Delhi, India - 110001',
  pan: process.env.ORG_PAN || 'AAAAA0000A', // PLACEHOLDER org PAN
  regNumber80G: process.env.ORG_80G_REG || 'PLACEHOLDER-80G-REG-NUMBER',
  regValidity80G: process.env.ORG_80G_VALIDITY || 'AY 2022-23 onwards (PLACEHOLDER)',
  email: process.env.ORG_EMAIL || 'donations@shikshasudhar.example',
  phone: process.env.ORG_PHONE || '+91 00000 00000',
  signatoryName: process.env.ORG_SIGNATORY || '[PLACEHOLDER] Authorized Signatory',
};
