require('dotenv').config();
require('express-async-errors');

const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const cookieParser = require('cookie-parser');
const rateLimit = require('express-rate-limit');
const path = require('path');
const fs = require('fs');

const projectsRouter = require('./routes/projects');
const donationsRouter = require('./routes/donations');
const contentRouter = require('./routes/content');
const authRouter = require('./routes/auth');

const app = express();

// CSP is off because the site loads Google Fonts, Google Sign-In and Razorpay.
app.use(helmet({ contentSecurityPolicy: false, crossOriginOpenerPolicy: false, crossOriginResourcePolicy: false }));
app.use(cors({ origin: process.env.CORS_ORIGIN || 'http://localhost:5173', credentials: true }));
app.use(morgan('dev'));
app.use(express.json());
app.use(cookieParser());

// Donation endpoints touch money, so they get a tighter rate limit than
// the rest of the read-only API.
const donationLimiter = rateLimit({ windowMs: 60 * 1000, max: 20 });

app.get('/health', (req, res) => res.json({ ok: true }));
app.use('/api/auth', authRouter);
app.use('/api/projects', projectsRouter);
app.use('/api/donations', donationLimiter, donationsRouter);
app.use('/api', contentRouter);

// 404 for anything unmatched under /api
app.use('/api', (req, res) => res.status(404).json({ error: 'Not found' }));

// Serve the built React site (frontend/dist) from this same server, so the
// whole website is ONE app: no CORS and no separate API address needed.
const distDir = path.join(__dirname, '..', '..', 'frontend', 'dist');
if (fs.existsSync(distDir)) {
  app.use(express.static(distDir));
  app.get('*', (req, res) => res.sendFile(path.join(distDir, 'index.html')));
}

// Central error handler — keeps stack traces out of API responses.
app.use((err, req, res, next) => {
  console.error(err);
  res.status(err.status || 500).json({ error: err.message || 'Internal server error' });
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`Shiksha Sudhar API running on port ${PORT}`));
