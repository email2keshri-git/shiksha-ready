const express = require('express');
const { z } = require('zod');
const repo = require('../repositories');
const { validate } = require('../middleware/validate');
const { requireAuth, requireRole } = require('../middleware/auth');

const router = express.Router();

// Shape a project the way the frontend cards need it, converting
// paise -> rupees and adding a computed progress percentage.
function toCard(project) {
  const progress = project.goalAmount
    ? Math.min(100, Math.round((project.raisedAmount / project.goalAmount) * 100))
    : 0;
  return {
    id: project.id,
    title: project.title,
    description: project.description,
    category: project.category,
    imageUrl: project.imageUrl,
    goalAmount: project.goalAmount / 100,
    raisedAmount: project.raisedAmount / 100,
    progress,
    donorCount: project.donorCount || 0,
    school: project.school,
  };
}

// Trending score: closeness-to-goal (progress) plus how many people have
// donated. Used to pick which projects to feature.
function trendingScore(project) {
  const progress = project.goalAmount
    ? Math.min(100, (project.raisedAmount / project.goalAmount) * 100)
    : 0;
  return progress + (project.donorCount || 0);
}

// GET /api/projects?category=SANITATION&featured=3
router.get('/', async (req, res) => {
  const { category, featured } = req.query;
  let projects = await repo.listProjects({ category });
  if (featured) {
    projects = [...projects]
      .sort((a, b) => trendingScore(b) - trendingScore(a))
      .slice(0, Number(featured));
  }
  res.json({ projects: projects.map(toCard) });
});

// GET /api/projects/:id
router.get('/:id', async (req, res) => {
  const project = await repo.getProject(req.params.id);
  if (!project) return res.status(404).json({ error: 'Project not found' });
  res.json({ project: toCard(project) });
});

const createProjectSchema = z.object({
  title: z.string().min(1).max(160),
  description: z.string().min(1).max(2000),
  category: z.enum([
    'INFRASTRUCTURE',
    'SANITATION',
    'DIGITAL_LEARNING',
    'LIBRARY',
    'SPORTS',
    'TEACHER_TRAINING',
  ]),
  imageUrl: z.string().max(500).optional(),
  goalAmount: z.number().int().positive(), // rupees
  school: z.string().min(1).max(200),
});

// POST /api/projects — admin-only. Creates a project and saves it to the DB.
// goalAmount is provided in rupees and stored in paise.
router.post('/', requireAuth, requireRole('ADMIN'), validate(createProjectSchema), async (req, res) => {
  const { goalAmount, ...rest } = req.body;
  const created = await repo.createProject({ ...rest, goalAmount: goalAmount * 100 });
  res.status(201).json({ project: toCard(created) });
});

const updateProjectSchema = z.object({
  title: z.string().min(1).max(160).optional(),
  description: z.string().min(1).max(2000).optional(),
  category: z
    .enum(['INFRASTRUCTURE', 'SANITATION', 'DIGITAL_LEARNING', 'LIBRARY', 'SPORTS', 'TEACHER_TRAINING'])
    .optional(),
  imageUrl: z.string().max(500).optional(),
  goalAmount: z.number().int().positive().optional(), // rupees
  isActive: z.boolean().optional(),
});

// PATCH /api/projects/:id — admin-only. Updates a project.
router.patch('/:id', requireAuth, requireRole('ADMIN'), validate(updateProjectSchema), async (req, res) => {
  const data = { ...req.body };
  if (data.goalAmount !== undefined) data.goalAmount = data.goalAmount * 100;
  const updated = await repo.updateProject(req.params.id, data);
  if (!updated) return res.status(404).json({ error: 'Project not found' });
  res.json({ project: toCard(updated) });
});

// DELETE /api/projects/:id — admin-only.
router.delete('/:id', requireAuth, requireRole('ADMIN'), async (req, res) => {
  const ok = await repo.deleteProject(req.params.id);
  if (!ok) return res.status(404).json({ error: 'Project not found' });
  res.json({ success: true });
});

module.exports = router;
