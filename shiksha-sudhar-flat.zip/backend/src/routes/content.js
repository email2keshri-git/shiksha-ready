const express = require('express');
const { z } = require('zod');
const repo = require('../repositories');
const { validate } = require('../middleware/validate');
const { requireAuth, requireRole } = require('../middleware/auth');

const router = express.Router();

// GET /api/stats -> homepage counters (schools supported, children impacted, etc.)
router.get('/stats', async (req, res) => {
  const stats = await repo.getStats();
  res.json({ stats });
});

// GET /api/impact -> Impact page content (outcomes, allocation, yearly growth).
router.get('/impact', async (req, res) => {
  const impact = await repo.getImpact();
  if (!impact) return res.status(404).json({ error: 'Impact content not found' });
  res.json({ impact });
});

// GET /api/stories?featured=3 -> testimonial cards (all, or top N featured).
router.get('/stories', async (req, res) => {
  const { featured } = req.query;
  let stories = await repo.getStories();
  if (featured) stories = stories.slice(0, Number(featured));
  res.json({ stories });
});

const createStorySchema = z.object({
  quote: z.string().min(1).max(1000),
  authorName: z.string().min(1).max(120),
  authorRole: z.string().min(1).max(160),
  imageUrl: z.string().max(500).optional(),
});

// POST /api/stories — admin-only. Creates a story and saves it to the DB.
router.post('/stories', requireAuth, requireRole('ADMIN'), validate(createStorySchema), async (req, res) => {
  const story = await repo.createStory(req.body);
  res.status(201).json({ story });
});

// DELETE /api/stories/:id — admin-only.
router.delete('/stories/:id', requireAuth, requireRole('ADMIN'), async (req, res) => {
  const ok = await repo.deleteStory(req.params.id);
  if (!ok) return res.status(404).json({ error: 'Story not found' });
  res.json({ success: true });
});

// GET /api/partners -> logo strip
router.get('/partners', async (req, res) => {
  const partners = await repo.getPartners();
  res.json({ partners });
});

const createPartnerSchema = z.object({
  name: z.string().min(1).max(120),
  logoUrl: z.string().max(500).optional(),
});

// POST /api/partners — admin-only. Adds a partner and saves it to the DB.
router.post('/partners', requireAuth, requireRole('ADMIN'), validate(createPartnerSchema), async (req, res) => {
  const partner = await repo.createPartner(req.body);
  res.status(201).json({ partner });
});

// DELETE /api/partners/:id — admin-only.
router.delete('/partners/:id', requireAuth, requireRole('ADMIN'), async (req, res) => {
  const ok = await repo.deletePartner(req.params.id);
  if (!ok) return res.status(404).json({ error: 'Partner not found' });
  res.json({ success: true });
});

// GET /api/organization -> NGO registration/address/mission for the About page.
router.get('/organization', async (req, res) => {
  const organization = await repo.getOrganization();
  if (!organization) return res.status(404).json({ error: 'Organization details not found' });
  res.json({ organization });
});

// GET /api/volunteer-openings -> current volunteer roles for the Get Involved page.
router.get('/volunteer-openings', async (req, res) => {
  const openings = await repo.getVolunteerOpenings();
  res.json({ openings });
});

// POST /api/newsletter/subscribe -> collect an email for updates.
const subscribeSchema = z.object({ email: z.string().email() });
router.post('/newsletter/subscribe', validate(subscribeSchema), async (req, res) => {
  await repo.subscribeNewsletter(req.body.email.toLowerCase().trim());
  res.json({ success: true });
});

// GET /api/impact-video -> URL-based impact video for the watch page.
router.get('/impact-video', async (req, res) => {
  const video = await repo.getImpactVideo();
  if (!video) return res.status(404).json({ error: 'Impact video not found' });
  res.json({ video });
});

// GET /api/videos -> all impact videos for the watch page playlist.
router.get('/videos', async (req, res) => {
  const videos = await repo.getVideos();
  res.json({ videos });
});

const createVideoSchema = z.object({
  title: z.string().min(1).max(160),
  description: z.string().max(1000).optional(),
  // Accepts a direct video URL (e.g. .mp4) or a social/YouTube link.
  videoUrl: z.string().min(1).max(1000),
});

// POST /api/videos — admin-only. Adds a video (direct URL or social link).
router.post('/videos', requireAuth, requireRole('ADMIN'), validate(createVideoSchema), async (req, res) => {
  const video = await repo.createVideo(req.body);
  res.status(201).json({ video });
});

// DELETE /api/videos/:id — admin-only.
router.delete('/videos/:id', requireAuth, requireRole('ADMIN'), async (req, res) => {
  const ok = await repo.deleteVideo(req.params.id);
  if (!ok) return res.status(404).json({ error: 'Video not found' });
  res.json({ success: true });
});

module.exports = router;
