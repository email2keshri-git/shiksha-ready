const express = require('express');
const crypto = require('crypto');
const { z } = require('zod');
const Razorpay = require('razorpay');
const repo = require('../repositories');
const org = require('../config/organization');
const { validate } = require('../middleware/validate');

const router = express.Router();

const razorpayConfigured = Boolean(
  process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET &&
  !process.env.RAZORPAY_KEY_ID.includes('xxxx')
);

const razorpay = razorpayConfigured
  ? new Razorpay({ key_id: process.env.RAZORPAY_KEY_ID, key_secret: process.env.RAZORPAY_KEY_SECRET })
  : null;

const createOrderSchema = z.object({
  projectId: z.string().optional(), // absent = general fund donation
  amount: z.number().int().positive(), // rupees
  donorName: z.string().min(1),
  donorEmail: z.string().email(),
  donorPhone: z.string().optional(),
  panNumber: z.string().optional(),
  isAnonymous: z.boolean().optional(),
  message: z.string().optional(),
});

// POST /api/donations/order
// Step 1: create a pending Donation row + a Razorpay order for the frontend
// checkout widget to open. Falls back to a fake order id when Razorpay
// keys aren't configured yet (stub/demo mode), so the flow still works
// end-to-end without a live payments account.
router.post('/order', validate(createOrderSchema), async (req, res) => {
  const { projectId, amount, ...donor } = req.body;
  const amountInPaise = amount * 100;

  const order = razorpayConfigured
    ? await razorpay.orders.create({
        amount: amountInPaise,
        currency: 'INR',
        receipt: `don_${Date.now()}`,
      })
    : { id: `order_stub_${Date.now()}` };

  const donation = await repo.createPendingDonation({
    amount: amountInPaise,
    donorName: donor.donorName,
    donorEmail: donor.donorEmail,
    donorPhone: donor.donorPhone,
    panNumber: donor.panNumber,
    isAnonymous: donor.isAnonymous ?? false,
    message: donor.message,
    razorpayOrderId: order.id,
    projectId: projectId || null,
  });

  res.json({
    donationId: donation.id,
    orderId: order.id,
    amount: amountInPaise,
    currency: 'INR',
    keyId: razorpayConfigured ? process.env.RAZORPAY_KEY_ID : null,
    demoMode: !razorpayConfigured,
  });
});

const verifySchema = z.object({
  donationId: z.string(),
  razorpay_order_id: z.string(),
  razorpay_payment_id: z.string(),
  razorpay_signature: z.string(),
});

// POST /api/donations/verify
// Step 2: frontend calls this after the Razorpay checkout succeeds. We
// re-derive the signature server-side so a client can't fake a "success".
// In stub/demo mode (no Razorpay keys) signature checks are skipped since
// there's no real checkout to verify against.
router.post('/verify', validate(verifySchema), async (req, res) => {
  const { donationId, razorpay_order_id, razorpay_payment_id, razorpay_signature } = req.body;

  const isValid = razorpayConfigured
    ? crypto
        .createHmac('sha256', process.env.RAZORPAY_KEY_SECRET)
        .update(`${razorpay_order_id}|${razorpay_payment_id}`)
        .digest('hex') === razorpay_signature
    : true;

  const donation = await repo.updateDonationStatus({
    donationId,
    status: isValid ? 'SUCCESS' : 'FAILED',
    razorpayPaymentId: razorpay_payment_id,
  });

  if (isValid && donation.projectId) {
    await repo.incrementProjectRaised(donation.projectId, donation.amount);
  }

  if (!isValid) return res.status(400).json({ error: 'Payment verification failed' });
  res.json({ success: true, donationId: donation.id });
});

// PAN is mandatory to issue an 80G receipt. Donors can add it after paying
// (the checkout form makes it optional). Only allowed once the payment has
// actually succeeded, so receipts can't be minted for unpaid donations.
const panSchema = z.object({
  panNumber: z
    .string()
    .transform((v) => v.toUpperCase().trim())
    .refine((v) => /^[A-Z]{5}[0-9]{4}[A-Z]$/.test(v), 'Invalid PAN format'),
});

router.post('/:id/pan', validate(panSchema), async (req, res) => {
  const donation = await repo.getDonationById(req.params.id);
  if (!donation) return res.status(404).json({ error: 'Donation not found' });
  if (donation.status !== 'SUCCESS') {
    return res.status(400).json({ error: 'Receipt is available only after a successful payment' });
  }
  const updated = await repo.updateDonationPan({ donationId: donation.id, panNumber: req.body.panNumber });
  res.json({ success: true, donationId: updated.id });
});

// GET /api/donations/:id/receipt
// Returns a self-contained, printable 80G receipt (HTML). Access is guarded
// by the unguessable donation id; add a signed token before production.
router.get('/:id/receipt', async (req, res) => {
  const donation = await repo.getDonationById(req.params.id);
  if (!donation) return res.status(404).send('Receipt not found');
  if (donation.status !== 'SUCCESS') {
    return res.status(400).send('Receipt is available only after a successful payment');
  }
  if (!donation.panNumber) {
    return res.status(400).send('A PAN is required to issue an 80G receipt');
  }

  let purpose = 'General Fund';
  if (donation.projectId) {
    const project = await repo.getProject(donation.projectId);
    if (project) purpose = project.title;
  }

  res.set('Content-Type', 'text/html; charset=utf-8').send(renderReceiptHtml({ donation, purpose }));
});

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, (c) => (
    { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
  ));
}

function renderReceiptHtml({ donation, purpose }) {
  const amountRupees = (donation.amount / 100).toLocaleString('en-IN', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
  const date = new Date(donation.createdAt || Date.now()).toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'long',
    year: 'numeric',
  });
  const receiptNo = `SS/80G/${String(donation.id).slice(-8).toUpperCase()}`;

  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>80G Donation Receipt — ${escapeHtml(receiptNo)}</title>
<style>
  * { box-sizing: border-box; }
  body { font-family: 'Segoe UI', Arial, sans-serif; color: #1c2b26; margin: 0; background: #f4f4f2; }
  .sheet { max-width: 760px; margin: 24px auto; background: #fff; padding: 40px; border: 1px solid #e5e7eb; }
  .head { display: flex; justify-content: space-between; border-bottom: 3px solid #1C4A39; padding-bottom: 16px; }
  .org { font-size: 20px; font-weight: 800; color: #1C4A39; }
  .muted { color: #6b7280; font-size: 12px; line-height: 1.5; }
  h1 { font-size: 16px; letter-spacing: .05em; text-transform: uppercase; text-align: center; margin: 24px 0 4px; color: #1C4A39; }
  .sub { text-align: center; color: #6b7280; font-size: 12px; margin-bottom: 24px; }
  table { width: 100%; border-collapse: collapse; margin-top: 8px; }
  td { padding: 10px 12px; border: 1px solid #e5e7eb; font-size: 14px; vertical-align: top; }
  td.k { background: #f8faf9; font-weight: 600; width: 38%; color: #374151; }
  .amount { font-size: 22px; font-weight: 800; color: #1C4A39; }
  .note { margin-top: 20px; font-size: 12px; color: #4b5563; line-height: 1.6; }
  .sign { margin-top: 48px; text-align: right; font-size: 13px; }
  .actions { text-align: center; margin: 16px; }
  button { background: #E1621B; color: #fff; border: 0; padding: 10px 20px; border-radius: 6px; font-size: 14px; cursor: pointer; }
  @media print { body { background: #fff; } .sheet { border: 0; margin: 0; } .actions { display: none; } }
</style>
</head>
<body>
  <div class="actions"><button onclick="window.print()">Print / Save as PDF</button></div>
  <div class="sheet">
    <div class="head">
      <div>
        <div class="org">${escapeHtml(org.name)}</div>
        <div class="muted">${escapeHtml(org.addressLine1)}<br>${escapeHtml(org.addressLine2)}<br>${escapeHtml(org.email)} · ${escapeHtml(org.phone)}</div>
      </div>
      <div class="muted" style="text-align:right">
        PAN: ${escapeHtml(org.pan)}<br>
        80G Reg. No: ${escapeHtml(org.regNumber80G)}<br>
        Validity: ${escapeHtml(org.regValidity80G)}
      </div>
    </div>

    <h1>Donation Receipt</h1>
    <div class="sub">Eligible for deduction under Section 80G of the Income Tax Act, 1961</div>

    <table>
      <tr><td class="k">Receipt No.</td><td>${escapeHtml(receiptNo)}</td></tr>
      <tr><td class="k">Date</td><td>${escapeHtml(date)}</td></tr>
      <tr><td class="k">Received from</td><td>${escapeHtml(donation.donorName)}</td></tr>
      <tr><td class="k">Donor PAN</td><td>${escapeHtml(donation.panNumber)}</td></tr>
      <tr><td class="k">Email</td><td>${escapeHtml(donation.donorEmail)}</td></tr>
      <tr><td class="k">Purpose</td><td>${escapeHtml(purpose)}</td></tr>
      <tr><td class="k">Payment reference</td><td>${escapeHtml(donation.razorpayPaymentId || donation.razorpayOrderId || '—')}</td></tr>
      <tr><td class="k">Amount donated</td><td class="amount">₹ ${amountRupees}</td></tr>
    </table>

    <p class="note">
      This receipt acknowledges the voluntary donation received towards the charitable objects of
      ${escapeHtml(org.name)}. No goods or services were provided in consideration of this donation.
      Please retain this receipt for claiming tax deduction under Section 80G.
    </p>

    <div class="sign">
      For <strong>${escapeHtml(org.name)}</strong><br><br>
      ${escapeHtml(org.signatoryName)}
    </div>
  </div>
</body>
</html>`;
}

module.exports = router;
