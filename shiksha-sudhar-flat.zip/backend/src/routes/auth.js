const express = require('express');
const crypto = require('crypto');
const { z } = require('zod');
const rateLimit = require('express-rate-limit');
const repo = require('../repositories');
const { validate } = require('../middleware/validate');
const { requireAuth } = require('../middleware/auth');
const { isGoogleConfigured, verifyGoogleCredential } = require('../lib/googleAuth');
const {
  hashPassword,
  verifyPassword,
  signToken,
  authCookieOptions,
  AUTH_COOKIE,
} = require('../lib/auth');

const router = express.Router();

// Brute-force protection: limit auth attempts per IP. Applied to login and
// register so normal session checks (/me) aren't throttled.
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  message: { error: 'Too many attempts. Please try again later.' },
  standardHeaders: true,
  legacyHeaders: false,
});

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
});

// POST /api/auth/login
// Verifies credentials and sets an httpOnly JWT cookie. Responses never
// reveal whether the email exists (no user enumeration).
router.post('/login', authLimiter, validate(loginSchema), async (req, res) => {
  const email = req.body.email.toLowerCase().trim();
  const user = await repo.getUserByEmail(email);

  const ok = user && (await verifyPassword(req.body.password, user.passwordHash));
  if (!ok) return res.status(401).json({ error: 'Invalid email or password' });

  const token = signToken(user);
  res.cookie(AUTH_COOKIE, token, authCookieOptions());
  res.json({ user: { id: user.id, name: user.name, email: user.email, role: user.role } });
});

const registerSchema = z.object({
  name: z.string().min(1).max(120),
  email: z.string().email(),
  password: z.string().min(8, 'Password must be at least 8 characters'),
});

// POST /api/auth/register
// Creates a donor account and logs them in (sets the auth cookie). New
// self-service signups are always DONOR — elevated roles are assigned
// separately, never from client input.
router.post('/register', authLimiter, validate(registerSchema), async (req, res) => {
  const email = req.body.email.toLowerCase().trim();
  const existing = await repo.getUserByEmail(email);
  if (existing) return res.status(409).json({ error: 'An account with this email already exists' });

  const passwordHash = await hashPassword(req.body.password);
  const user = await repo.createUser({
    name: req.body.name.trim(),
    email,
    passwordHash,
    role: 'DONOR',
  });

  const token = signToken(user);
  res.cookie(AUTH_COOKIE, token, authCookieOptions());
  res.status(201).json({ user: { id: user.id, name: user.name, email: user.email, role: user.role } });
});

// GET /api/auth/google/config -> lets the frontend know if Google sign-in is on.
router.get('/google/config', (req, res) => {
  res.json({ enabled: isGoogleConfigured() });
});

const googleSchema = z.object({ credential: z.string().min(1) });

// POST /api/auth/google
// Verifies a Google ID token, then signs in an existing user or creates a
// new DONOR account linked by verified email, and sets our auth cookie.
router.post('/google', authLimiter, validate(googleSchema), async (req, res) => {
  if (!isGoogleConfigured()) {
    return res.status(501).json({ error: 'Google sign-in is not configured' });
  }

  let profile;
  try {
    profile = await verifyGoogleCredential(req.body.credential);
  } catch {
    return res.status(401).json({ error: 'Could not verify Google sign-in' });
  }

  let user = await repo.getUserByEmail(profile.email);
  if (!user) {
    // Google-authenticated account: store a random, unusable password hash
    // so there's no password-login path for it.
    const randomHash = await hashPassword(crypto.randomBytes(32).toString('hex'));
    user = await repo.createUser({
      name: profile.name,
      email: profile.email,
      passwordHash: randomHash,
      role: 'DONOR',
    });
  }

  const token = signToken(user);
  res.cookie(AUTH_COOKIE, token, authCookieOptions());
  res.json({ user: { id: user.id, name: user.name, email: user.email, role: user.role } });
});

// POST /api/auth/logout — clears the auth cookie.
router.post('/logout', (req, res) => {
  res.clearCookie(AUTH_COOKIE, { ...authCookieOptions(), maxAge: undefined });
  res.json({ success: true });
});

// GET /api/auth/me — returns the current user from the session cookie.
router.get('/me', requireAuth, async (req, res) => {
  const user = await repo.getUserById(req.user.id);
  if (!user) return res.status(401).json({ error: 'Invalid session' });
  res.json({ user: { id: user.id, name: user.name, email: user.email, role: user.role } });
});

module.exports = router;
