// Creates (or resets) the admin login. Reads ADMIN_NAME, ADMIN_EMAIL and
// ADMIN_PASSWORD from the environment, so the password never lives in code.
require('dotenv').config();
const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');

async function main() {
  const email = (process.env.ADMIN_EMAIL || '').toLowerCase().trim();
  const password = process.env.ADMIN_PASSWORD || '';
  const name = process.env.ADMIN_NAME || 'NGO Admin';
  if (!email || password.length < 10) {
    throw new Error('Set ADMIN_EMAIL and ADMIN_PASSWORD (at least 10 characters) first.');
  }
  const prisma = new PrismaClient();
  const passwordHash = bcrypt.hashSync(password, 10);
  await prisma.user.upsert({
    where: { email },
    update: { passwordHash, role: 'ADMIN', name },
    create: { email, passwordHash, role: 'ADMIN', name },
  });
  console.log(`Admin ready: ${email}`);
  await prisma.$disconnect();
}
main().catch((e) => { console.error(e.message); process.exit(1); });
