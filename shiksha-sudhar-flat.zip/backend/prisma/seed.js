const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function main() {
  await prisma.donation.deleteMany();
  await prisma.project.deleteMany();
  await prisma.school.deleteMany();
  await prisma.story.deleteMany();
  await prisma.partner.deleteMany();
  await prisma.impactStat.deleteMany();

  const karnatakaSchool = await prisma.school.create({
    data: { name: 'Zila Parishad School', state: 'Karnataka', city: 'Mysuru' },
  });
  const rajasthanSchool = await prisma.school.create({
    data: { name: 'Government School', state: 'Rajasthan', city: 'Jodhpur' },
  });
  const tamilNaduSchool = await prisma.school.create({
    data: { name: 'Municipal School', state: 'Tamil Nadu', city: 'Chennai' },
  });

  await prisma.project.createMany({
    data: [
      {
        title: 'Build 3 New Classrooms',
        description: 'Help us build 3 additional classrooms to accommodate 300+ more students.',
        category: 'INFRASTRUCTURE',
        imageUrl: '/images/classrooms.jpg',
        goalAmount: 1500000 * 100,
        raisedAmount: 925000 * 100,
        schoolId: karnatakaSchool.id,
      },
      {
        title: 'Safe and Clean Toilets for Girls',
        description: 'Support the construction of separate and hygienic toilet blocks for girls.',
        category: 'SANITATION',
        imageUrl: '/images/toilets.jpg',
        goalAmount: 1000000 * 100,
        raisedAmount: 400000 * 100,
        schoolId: rajasthanSchool.id,
      },
      {
        title: 'Digital Classrooms',
        description: 'Provide computers, smart boards and digital learning tools for a better future.',
        category: 'DIGITAL_LEARNING',
        imageUrl: '/images/digital.jpg',
        goalAmount: 1500000 * 100,
        raisedAmount: 1170000 * 100,
        schoolId: tamilNaduSchool.id,
      },
    ],
  });

  await prisma.story.createMany({
    data: [
      {
        quote: 'Our new classroom has made learning so much easier and fun!',
        authorName: 'Priya',
        authorRole: 'Class 6, ZP School Karnataka',
        imageUrl: '/images/priya.jpg',
      },
      {
        quote: 'The computer lab has opened a new world for us.',
        authorName: 'Arjun',
        authorRole: 'Class 8, Municipal School Tamil Nadu',
        imageUrl: '/images/arjun.jpg',
      },
      {
        quote: 'These facilities have brought real hope to our community.',
        authorName: 'School Teacher',
        authorRole: 'Government School, Rajasthan',
        imageUrl: '/images/teacher.jpg',
      },
    ],
  });

  await prisma.partner.createMany({
    data: [
      { name: 'TATA', logoUrl: '/logos/tata.svg' },
      { name: 'Infosys', logoUrl: '/logos/infosys.svg' },
      { name: 'HCL', logoUrl: '/logos/hcl.svg' },
      { name: 'Microsoft', logoUrl: '/logos/microsoft.svg' },
      { name: 'Google', logoUrl: '/logos/google.svg' },
      { name: 'Accenture', logoUrl: '/logos/accenture.svg' },
      { name: 'Reliance Foundation', logoUrl: '/logos/reliance.svg' },
    ],
  });

  await prisma.impactStat.createMany({
    data: [
      { label: 'Schools Supported', value: '1,250+' },
      { label: 'Children Impacted', value: '3,50,000+' },
      { label: 'Funds Raised', value: '₹120+ Crore' },
      { label: 'States Across India', value: '28' },
    ],
  });

  console.log('Seed complete.');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
